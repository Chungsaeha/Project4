/**
 * @module mixin/page
 * @desc page mixin to create page component. if create page component, mix in it
 * @example
 * import page from 'obigo-js-ui/src/mixins/page'
 * export default{
 *   mixins: [page],
 *   data () {
 *     return { }
 *   },
 *   methods {
 *     // define methods
 *   },
 *   mounted () {
 *     // to do
 *   }
 * }
 *
 */
const pageMixin = {
  methods: {
    /**
     * @function setTitle
     * @desc to set page title.
     * @param {string} title - text to set title
     *
     */
    setTitle (title) {
      if (typeof title === 'string') {
        this._title = title
      } else if (this._title === this._appName) {
        let wd = this._application.getDescriptor()
        let lang = this._application.getLanguage()
        let name = wd.getWidgetName(lang)
        if (name) {
          this._title = name
          this._appName = name
        } else {
          this._title = '(No title)'
        }
      }
      try {
        this._application.setStatusBarTitle(this.$t(this._title))
      } catch (e) {
        console.log(e.message)
      }
    }
  },
  mounted () {
    if (window.applicationFramework) {
      this._application = window.applicationFramework.applicationManager.getOwnerApplication(window.document)
      this._application.addEventListener('ApplicationShown', this.setTitle, false)
      this._title = ''
      let wd = this._application.getDescriptor()
      let lang = this._application.getLanguage()

      let name = wd.getWidgetName(lang)
      if (name) {
        this._title = name
        this._appName = name
      } else {
        this._title = '(No title)'
      }
    }

    this.$focus.setScene(this.scene)
  },
  activated () {
    this.$focus.setScene(this.scene)
  },
  beforeDestroy () {
    if (window.applicationFramework) {
      this._application.removeEventListener('ApplicationShown', this.setTitle, false)
    }

    this.$focus.storeLastFocusInfo(this.scene)
  },
  deactivated () {
    this.$focus.storeLastFocusInfo(this.scene)
  },
  data () {
    return {
      scene: 0
    }
  },
  watch: {
    scene (newScene, oldScene) {
      this.$focus.storeLastFocusInfo(oldScene)
      this.$focus.setScene(newScene)
    }
  }
}
export default pageMixin
