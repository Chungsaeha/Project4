<template>
  <div
    class="obg-range"
    :class="{ 'obg-range-disabled': disabled }"
    :style="{ 'width': rangeWidth + 'px'}"
    data-type="focus-control-able"
    @click.stop
  >
    <button
      class="obg-range-button down"
      :class="{'disabled': (min === model)}"
      ref="down"
      @click="valueDown"
    >
    </button>
    <div
      class="obg-slider-wrapper"
      :style="{width: (rangeWidth - 110) + 'px'}"
      ref="slider"
      @mousedown.stop="onPressSlider"
      @mouseup="onReleaseSlider"
      @touchstart.stop="onPressSlider"
      @touchend="onReleaseSlider"
    >
      <obg-slider
        class="slider-body"
        mode="range"
        :min="min"
        :max="max"
        :step="sliderStep"
        :sliderWidth="rangeWidth - 150"
        :barHeight="barHeight"
        :focus="focus"
        v-model="model"
        @input="onInput"
        :thumbScale="false"
        :thumbLabel="true"
      ></obg-slider>
    </div>
    <button
      class="obg-range-button up"
      :class="{'disabled': (max === model)}"
      ref="up"
      @click="valueUp"
    >
    </button>
  </div>
</template>
<script type="text/babel">
  /**
   * @class range
   * @classdesc components/range
   * @param {number} [min=0]
   * @param {number} [max=100]
   * @param {number} [step=1]
   * @param {number} [value=0]
   * @param {number} [barHeight=43]
   * @param {number} [rangeWidth=500]
   * @param {number} [stepPercent=1]
   * @param {boolean} [draggable=true]
   * @param {boolean} [disabled=false]
   * @param {event} [input]
   *
   * @example
   * <obg-range
   *  v-model="model"
   *  :min="0"
   *  :max="100"
   *  :step="10" @input="onInput"
   *  ></obg-range>
   */
  import longpress from '../../features/longPress'
  import slider from '../slider'
  import focusControlMixin from '../../mixins/focus-control'

  export default {
    name: 'obg-range',
    components: {
      'obg-slider': slider
    },
    mixins: [focusControlMixin],
    props: {
      min: {
        type: Number,
        default: 0
      },
      max: {
        type: Number,
        default: 100
      },
      step: {
        type: Number,
        default: 1
      },
      disabled: {
        type: Boolean,
        default: false
      },
      value: {
        type: Number,
        default: 0
      },
      barHeight: {
        type: Number,
        default: 43
      },
      rangeWidth: {
        type: Number,
        default: 500
      },
      stepPercent: {
        type: Number,
        default: 1
      }
    },
    data () {
      return {
        model: (this.value < this.min) ? this.min : this.value,
        focus: false,
        counter: 0,
        weight: 1,
        clickPosX: 0
      }
    },
    computed: {
      sliderStep () {
        return Math.ceil((this.max - this.min) / 100) * this.step
      }
    },
    mounted () {
      const up = this.$refs.up
      const down = this.$refs.down
      this.onepercent = Math.ceil((this.max - this.min) / 100)
      longpress(up, {
        counter: () => {
          // this.addCount()
          this.valueUp()
        },
        end: () => {
          this.onInput(this.model)
          this.reset()
        }
      })
      longpress(down, {
        counter: () => {
          // this.addCount()
          this.valueDown()
        },
        end: () => {
          this.onInput(this.model)
          this.reset()
        }
      })
      this.$on('focusout', () => {
        this.focus = false
      })
    },
    methods: {
      valueDown () {
        // this.model = this.model - this.onepercent * this.weight
        this.model = this.model - this.onepercent * this.step
        if (this.model < this.min) this.model = this.min
        this.$emit('input', this.model)
      },
      valueUp () {
        // this.model = this.model + this.onepercent * this.weight
        this.model = this.model + this.onepercent * this.step
        if (this.model > this.max) this.model = this.max
        this.$emit('input', this.model)
      },
      onInput (val) {
        this.$emit('input', val)
      },
      reset () {
        this.counter = 0
        this.onepercent = Math.ceil((this.max - this.min) / 100)
        this.weight = 1
      },
      addCount () { // TODO 가중치에 대해서는 논의 후 결정
        this.counter++
        if (this.counter % 8 === 0) {
          if (this.weight < 12) {
            this.weight += 4
          } else {
            this.weight = 10
          }
        }
      },
      onPressSlider (event) {
        this.clickPosX = (typeof event.pageX !== 'undefined') ? event.pageX : event.touches[0].pageX
      },
      onReleaseSlider (event) {
        if (event.changedTouches && event.changedTouches[0]) {
          event = event.changedTouches[0]
        }
        const pageX = event.pageX
        const target = (event.srcElement) ? event.srcElement : event.target
        if (Math.abs(this.clickPosX - pageX) < 5 && !target.classList.contains('obg-slider-thumb') && !target.classList.contains('obg-slider-current-value')) {
          const contentBox = this.$refs.slider.getBoundingClientRect()
          const deltaX = pageX - contentBox.left
          let newProgress = Math.floor(this.max * deltaX / contentBox.width)
          if (newProgress < this.min) {
            newProgress = this.min
          } else if (newProgress > this.max) {
            newProgress = this.max
          }
          this.$emit('input', newProgress)
          this.model = newProgress
        }
        this.clickPosX = 0
      },
      onControlIn () {
        this.$el.querySelector('.obg-slider-thumb').classList.add('obg-focus')
        this.$el.addEventListener('mousedown', this.exitFocusMode)
        this.$refs.slider.addEventListener('mousedown', this.exitFocusMode)
      },
      onRotate ({mode}) {
        if (mode === this.hardkeyCodes.mode.HARDKEY_MODE_RIGHT) {
          this.valueUp()
        } else {
          this.valueDown()
        }
      },
      onRotateClick () {
        this.$el.querySelector('.obg-slider-thumb').classList.remove('obg-focus')
        this.$el.removeEventListener('mousedown', this.exitFocusMode)
        this.$refs.slider.removeEventListener('mousedown', this.exitFocusMode)
      },
      exitFocusMode () {
        this.$el.removeEventListener('mousedown', this.exitFocusMode)
        this.$refs.slider.removeEventListener('mousedown', this.exitFocusMode)
        this.exitFocusControlMode()
        this.$focus.exitFocusMode()
      }
    }
  }
</script>

<style lang="scss" scoped>
/*
  @import '../../styles/common/colors.variables';
  */

  .obg-range {
    position: relative;
    display: flex;
    height: 47px;
    line-height: 47px;
    border-radius: 47px;
    color: color(black);
    box-shadow: inset 0 0 0 2px rgb(161,162,179); /* color(grey-3); */
    text-align: center;
    align-items: center;
    justify-content: center;
    & > .obg-range-button {
      height: 37px;
      width: 56px;
      background-color: rgb(34,34,38); /* color(grey-1); */
      color: #ffffff; /* color(white); */
      font-size: 32px;
      outline: none;
      user-select: none;
      line-height: 28px;
      text-indent: 9px;
      &.disabled {
        pointer-events: none;
        border-color: #a1a2b3 !important;
      }
      &:active {
        border-color: #a1a2b3 !important;
        box-shadow: none;
        color: #ffffff; /* color(white); */
        background-color: #14385c;
      }
      &.down {
        margin-right: -9px;
        border-radius: 30px 0 0 30px;
        border-color: #a1a2b3 transparent #a1a2b3 #a1a2b3;
        &:active {
          border-right-width: 2px;
        }
        &:after {
          content: '';
          top: 0px;
          left: 20px;
          border: 1px solid #fff;
          display: block;
          width: 15px;
          position: relative;
        }
        &.disabled {
          border-right-width: 2px;
          &:before, &:after {
            border-color: #555;
          }
        }
      }
      &.up {
        margin-left: -1px;
        border-radius: 0 30px 30px 0;
        border-color: #a1a2b3 #a1a2b3 #a1a2b3 transparent;
        &:active {
          border-left-width: 1px;
          z-index: 2;
        }
        &.disabled {
          border-left-width: 1px;
          z-index: 2;
          &:before, &:after {
            border-color: #555;
          }
        }
        &:before {
          content: '';
          border: 1px solid #ffffff; /* color(white); */
          display: block;
          height: 15px;
          float: left;
          margin-left: 23px;
          margin-top: 2px;
        }
        &:after {
          content: '';
          top: 9px;
          left: 15px;
          border: 1px solid #ffffff; /* color(white); */
          display: block;
          width: 15px;
          position: relative;
        }
      }
    }
    & > .obg-slider-wrapper {
      height: 45px;
      border-top: 1px solid #a1a2b3;
      border-bottom: 1px solid #a1a2b3;
      z-index: 1;
      background: #212125;
    }
    &.obg-range-disabled {
      opacity: 0.5;
      user-select: none;
      pointer-events: none;
    }
  }

</style>
