<template>
  <div class='obg-scroll-view' >
    <div class='scroll-container' >
      <slot></slot>
      <div class='dummy-item' v-if="hideDummyItem == false && isEmpty == false" ></div>
    </div>
  </div>
</template>

<script>
import IScroll from '../../features/iscroll'
/**
 * @class scrollview
 * @classdesc components/scroll-view
 * @param {boolean} [hideDummyitem=false]
 * @example
 * <obg-scroll-view>
 *  some content in here
 * </obg-scroll-view>
 */
export default {
  name: 'obg-scroll-view',
  props: {
    hideDummyItem: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      isEmpty: true
    }
  },
  methods: {
    makeScroll: function () {
      if (this.$slots.default === undefined || this.$slots.default.length === 0) {
        this.isEmpty = true
        return
      }
      this.isEmpty = false
      this.$scroll = new IScroll(this.$el, {
        probeType: 2,
        bounce: true,
        mouseWheel: false,
        scrollbars: true,
        fadeScrollbars: true,
        interactiveScrollbars: false,
        click: true,
        disableMouse: false,
        disableTouch: false,
        disablePointer: true,
        dummyItem: !this.hideDummyItem,
        preventDefaultException: {
          // default config, all form elements,
          // extended with a WebComponents Custom Element from the future
          tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT|X-WIDGET)$/,
          // and allow any element that has an accessKey (because we can)
          accessKey: /.+/
        }
      })
    },
    refreshScroll: function () {
      if (this.$scroll) {
        if (this.$slots.default === undefined || this.$slots.default.length === 0) {
          this.isEmpty = true
          return
        } else {
          this.isEmpty = false
          this.$scroll.refresh()
        }
      } else {
        this.makeScroll()
      }
    }
  },
  updated: function () {
    this.refreshScroll()
  },
  mounted: function () {
    this.makeScroll()
  },
  beforeDestroy: function () {
    if (this.$scroll) {
      this.$scroll.destroy()
      this.$scroll = undefined
    }
  }

}
</script>
<style lang="scss" scoped >
  .obg-scroll-view{
    width:100%;
    height:420px;
    position:relative;
    overflow:hidden;
    color:white;
    .dummy-item{
      width:100%;
      height:78px;
    }
  }
</style>

