<template>
    <div class="obg-carousel-container">
      <div class="obg-carousel-slider">
        <slot></slot>
      </div>
      <div class="scroll-bar" v-show="scrollBar">

      </div>
    </div>
</template>

<script>
  /**
   * @class cover-flow
   * @classdesc components/cover-flow
   * @param {boolean} [loop=true]
   * @param {number} [perspective=35]
   * @param {number} [display=5] 3 | 5
   * @param {number} [animationSpeed=500] ms
   * @param {number} [startIndex=0]
   * @param {number} [width=300]
   * @param {number} [height=210]
   * @param {boolean} [dim=true]
   * @param {number} [inverseScaling=300]
   * @param {boolean} [scrollBar=true]
   * @param {array} [slideRatio=[{x: 250, z: 235}, {x: 800, z: 1333}, {x: 1400, z: 1333}]]
   * @param {slot} [slot] Cover-slide
   * @example
   * <obg-cover-flow @input="onChange" >
   *   <obg-cover-slide v-for="n in 11" :index="n-1">
   *     Slide {{n}} Content
   *   </obg-cover-slide>
   * </obg-cover-flow>
   */
  import {parentMixin} from '../../mixins/cover-flow'
  export default {
    name: 'obg-cover-flow',
    mixins: [parentMixin],
    props: {
      perspective: {
        type: Number,
        default: 35
      },
      display: {
        type: Number,
        default: 5,
        validator (val) {
          return val === 3 || val === 5
        }
      },
      dim: {
        type: Boolean,
        default: true
      },
      width: {
        type: Number,
        default: 210
      },
      height: {
        type: Number,
        default: 210
      },
      inverseScaling: {
        type: Number,
        default: 300
      },
      scrollBar: {
        type: Boolean,
        default: true
      },
      slideRatio: {
        type: Array,
        default: () => { return [{x: 250, z: 235}, {x: 800, z: 1333}, {x: 1400, z: 1333}] }
      }
    },
    data () {
      return {
        dragStartX: 0
      }
    },
    methods: {
      /**
       * Trigger actions when mouse is pressed
       * @param  {Object} e The event object
       */
      handleMousedown (e) {
        e.preventDefault()

        this.animationStartTime = Date.now()
        this.mousedown = true
        this.dragStartX = (typeof e.clientX !== 'undefined') ? e.clientX : e.touches[0].clientX
      },
      /**
       * Trigger actions when mouse is pressed and then moved (mouse drag)
       * @param  {Object} e The event object
       */
      handleMousemove (e) {
        if (!this.mousedown) {
          return
        }

        const eventPosX = (typeof e.clientX !== 'undefined') ? e.clientX : e.touches[0].clientX
        const deltaX = (this.dragStartX - eventPosX)
        const now = Date.now()
        const gapTime = now - this.animationStartTime

        this.dragOffset = deltaX

        if (Math.abs(this.dragOffset) > this.minSwipeDistance) {
          this.$emit('slide-start')
          if (gapTime > this.minSwipeTime) {
            // no swipe
            if (this.dragOffset > 0) {
              this.handleMouseup(e)
              this.goNext()
            } else {
              this.handleMouseup(e)
              this.goPrev()
            }
          } else {
            // swipe
            let swipeCount = Math.abs(Math.floor(this.dragOffset / 15))
            // let targetIndex
            if (this.dragOffset > 0) {
              this.handleMouseup(e)
              this.swipeNext(swipeCount)
            } else {
              this.handleMouseup(e)
              this.swipePrev(swipeCount)
            }
          }
        }
      },
      /**
       * Trigger actions when mouse is released
       * @param  {Object} e The event object
       */
      handleMouseup (e) {
        this.$emit('slide-end')
        this.mousedown = false
        this.dragOffset = 0
        this.animationStartTime = 0
      },
      swipeNext (count) {
        let timeBuff = 0
        let i = 0

        while (i < count) {
          i += 1
          const timeout = (count === 1) ? 0 : (timeBuff)
          setTimeout(() => this.goNext(), timeout)

          timeBuff += ((this.animationSpeed * 3) / (count))
        }
      },
      swipePrev (count) {
        let timeBuff = 0
        let i = 0

        while (i < count) {
          i += 1
          const timeout = (count === 1) ? 0 : (timeBuff)
          setTimeout(() => this.goPrev(), timeout)

          timeBuff += ((this.animationSpeed * 3) / (count))
        }
      },
      /**
       * Re-compute the number of slides and current slide
       */
      computeData () {
        this.total = this.getSlideCount()
        this.currentIndex = this.startIndex > this.total - 1 ? this.total - 1 : this.startIndex
        this.viewport = this.$el.clientWidth
      },
      setSize () {
        this.$el.style.cssText += 'height:' + this.slideHeight
        this.$el.childNodes[0].style.cssText += 'width:' + this.slideWidth + 'px;' + ' height:' + this.slideHeight + 'px'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .obg-carousel-container {
    width: 100%;
    position: relative;
    z-index: 0;
    overflow: hidden;
    margin: auto;
    box-sizing: border-box;
    & > .obg-carousel-slider {
      position: relative;
      margin: 0 auto;
      transform-style: preserve-3d;
      -webkit-perspective: 1000px;
      perspective: 1000px;
    }
  }



</style>
