import coverFlow from './carousel.vue'
export {coverFlow}
import coverSlide from './slide.vue'
export {coverSlide}
