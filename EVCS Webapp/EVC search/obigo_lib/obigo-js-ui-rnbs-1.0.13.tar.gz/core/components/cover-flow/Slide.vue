<template>
  <div class="obg-carousel-slide" :style="slideStyle" :class="['step-' + stepNumber ,{ 'current': isCurrent, 'dim': parent.dim, 'obg-focus': focus }]" @click="goTo()">
    <div class="cover"></div>
    <slot></slot>
  </div>
</template>

<script>
  /**
   * @class cover-slide
   * @classdesc components/cover-flow
   *
   * @example
   * <obg-cover-flow @input="onChange">
   *   <obg-cover-slide v-for="n in 11" :index="n-1">
   *     Slide {{n}} Content
   *   </obg-cover-slide>
   * </obg-cover-flow>
   */
  import {childMixin} from '../../mixins/cover-flow'
  export default {
    name: 'obg-cover-slide',
    mixins: [childMixin],
    computed: {
      isCurrent () {
        return this.index === this.parent.currentIndex
      },
      slideStyle () {
        let styles = {}
        let animationSpeed = this.parent.animationSpeed
        this.stepNumber = 0
        if (!this.isCurrent) {
          const rIndex = this.getSideIndex(this.parent.rightIndices)
          const lIndex = this.getSideIndex(this.parent.leftIndices)

          if (this.parent.hasHiddenSlides) {
            if (this.matchIndex(this.parent.leftOutIndex)) {
              styles = this.calculatePosition(this.parent.leftIndices.length)
            } else if (this.matchIndex(this.parent.rightOutIndex)) {
              styles = this.calculatePosition(this.parent.rightIndices.length, true)
            } else {
              animationSpeed = 0
              styles.opacity = 0
              styles.visibility = 'hidden'
            }
          }

          if (rIndex >= 0 || lIndex >= 0) {
            if (rIndex >= 0) {
              this.stepNumber = rIndex + 1
              styles = this.calculatePosition(rIndex, true)
            } else {
              this.stepNumber = lIndex + 1
              styles = this.calculatePosition(lIndex)
            }
            styles.opacity = 1
            styles.visibility = 'visible'
            animationSpeed = this.parent.animationSpeed
          }
        }

        return Object.assign(styles, {
          'width': this.parent.slideWidth + 'px',
          'height': this.parent.slideHeight + 'px',
          'transition': ' transform ' + animationSpeed + 'ms, ' +
          '               opacity ' + animationSpeed + 'ms, ' +
          '               visibility ' + animationSpeed + 'ms, ' +
          '               -webkit-transform ' + animationSpeed + 'ms, ' +
          '               -webkit-opacity ' + animationSpeed + 'ms, ' +
          '               -webkit-visibility ' + animationSpeed + 'ms'
        })
      }
    },
    methods: {
      calculatePosition (i, positive) {
        const leftRemain = this.parent.slideRatio[i].x
        const inverseScaling = this.parent.slideRatio[i].z
        const transform = (positive)
          ? 'translateX(' + (leftRemain) + 'px) translateZ(-' + inverseScaling + 'px) '
          : 'translateX(-' + (leftRemain) + 'px) translateZ(-' + inverseScaling + 'px) '
        const top = 0

        return {
          transform: transform,
          top: top
        }
      }
    },
    data () {
      return {
        stepNumber: 0,
        focus: false
      }
    },
    mounted () {
      this.$on('focusin', () => {
        this.goTo(false)
        this.focus = true
      })
      this.$on('focusout', () => {
        this.focus = false
      })
    }
  }
</script>

<style lang="scss" scoped>
  .obg-carousel-slide {
    position: absolute;
    opacity: 0;
    visibility: hidden;
    overflow: hidden;
    top: 0;
    background-size: cover;
    background-color: #000000;
    border: 1px solid #6a6a6a;
    display: block;
    margin: 0;
    box-sizing: border-box;
    -webkit-transition: -webkit-transform .5s, -webkit-transform 500ms, opacity 500ms, visibility 500ms;
    &.obg-focus{
      & > .cover{
        box-shadow: inset 0 0 0 4px #ffffff;
      }
    }
    &.dim{
      &:before {
        display:block;
        width:100%;
        height:100%;
        content:'';
      }
    }
    &.step-0{
      background-color: #000000;
      opacity: .8;
      &.current{
        background-color: transparent;
      }
    }
    &.dim{
      &.step-1{
        &:before{
          background-color: #000000;
          opacity: .5;
        }
      }
    }
    &.dim{
      &.step-2{
        &:before{
          background-color: #000000;
          opacity: .8;
        }
      }
    }
    & > .cover{
      position: absolute;
      top: 0;
      left: 0;
      display: block;
      width: 100%;
      height: 100%;
    }
    &.focus{
      & > .cover {
        box-shadow: inset 0 0 0 4px #ffffff;
      }
    }
    &:active{
      & > .cover{
        background-color: rgba(0, 120, 240, 0.5);
      }
    }
  }

  .obg-carousel-slide img {
    width: 100%;
  }

  .obg-carousel-slide.current {
    opacity: 1 !important;
    visibility: visible !important;
    transform: none !important;
    -webkit-transform: none !important;
    z-index: 99;
  }

</style>
