<template>
  <div class='container'
    @mousedown='containerStart'
    :class='{disabled: disabled, active: active}'
  >
    <input type="checkbox" @click.stop  :disabled="disabled" :value='val' v-model="model">
    <div class="outer" >
      <div class='area' >
        <div class='indicator'
          @mousedown='indicatorStart'
        >{{indicatorText}}</div>
      </div>
    </div>
  </div>
</template>

<script>
/**
 * @class switch
 * @classdesc components/switch
 * @param {boolean} [v-model=true] required
 * @param {boolean} [disabled=false]
 *
 *
 * @example
 * <obg-switch v-model='val' ></obg-switch>
 */
export default {
  name: 'obg-switch',
  methods: {
    clickHandler (e) {
      // for focus click
      if (this.disabled) {
        return
      }
      this.model = !this.model
      this.updateIndicatorX()
    },
    containerStart (e) {
      if (this.disabled) {
        return
      }
      this.isContainerDown = true
      this.active = true
      this.$el.addEventListener('mouseup', this.containerEnd, false)
      this.$el.addEventListener('mousecancel', this.containerCancel, false)
      this.$el.addEventListener('mouseleave', this.containerCancel, false)
      this.$el.removeEventListener('click', this.clickHandler)
      e.stopPropagation()
    },
    containerCancel (e) {
      this.active = false
      this.$el.removeEventListener('mouseup', this.containerEnd)
      this.$el.removeEventListener('mousecancel', this.containerCancel)
      this.$el.removeEventListener('mouseleave', this.containerCancel)
      this.$el.addEventListener('click', this.clickHandler, false)
    },
    containerEnd (e) {
      this.active = false
      this.model = !this.model
      this.updateIndicatorX()

      this.$el.removeEventListener('mouseup', this.containerEnd)
      this.$el.removeEventListener('mousecancel', this.containerCancel)
      this.$el.removeEventListener('mouseleave', this.containerCancel)
      setTimeout(() => {
        this.$el.addEventListener('click', this.clickHandler, false)
      }, 0)
      e.stopPropagation()
    },
    indicatorStart (e) {
      if (this.disabled) {
        return
      }
      this.isIndicatorMove = false
      this.active = true
      this.beforeX = e.x
      this.addBodyEvent()
      this.indicator.addEventListener('mouseup', this.indicatorEnd, false)
      this.indicator.addEventListener('mousemove', this.indicatorMove, false)
      this.$el.removeEventListener('click', this.clickHandler)
      e.stopPropagation()
    },
    indicatorEnd (e) {
      this.active = false

      if (this.isIndicatorMove === false) {
        this.model = !this.model
        this.updateIndicatorX()
      } else {
        if (this.indicatorX < (this.max + this.min) / 2) {
          this.indicatorX = this.min
          this.model = false
        } else {
          this.indicatorX = this.max
          this.model = true
        }
        this.indicator.style.transform = 'translateX(' + this.indicatorX + 'px)'
        this.indicator.style.WebkitTransform = 'translateX(' + this.indicatorX + 'px)'
      }

      this.indicator.removeEventListener('mouseup', this.indicatorEnd)
      this.indicator.removeEventListener('mousemove', this.indicatorMove)

      setTimeout(() => {
        // setTimeout 하지 않으면 mouseup이벤트 이후 바로 click이벤트가 발생하여
        // 해당 이벤트 처리기가 수행됨
        this.$el.addEventListener('click', this.clickHandler, false)
      }, 0)
      this.removeBodyEvent()
      e.stopPropagation()
    },
    indicatorMove (e) {
      var diff = e.x - this.beforeX
      this.isIndicatorMove = true
      this.indicatorX += diff
      this.indicatorX = Math.max(Math.min(this.indicatorX, this.max), this.min)
      this.indicator.style.transform = 'translateX(' + this.indicatorX + 'px)'
      this.indicator.style.WebkitTransform = 'translateX(' + this.indicatorX + 'px)'
      this.beforeX = e.x
      e.stopPropagation()
    },
    addBodyEvent () {
      document.body.addEventListener('mouseup', this.indicatorEnd, false)
      document.body.addEventListener('mouseleave', this.indicatorEnd, false)
      document.body.addEventListener('mousemove', this.indicatorMove, false)
      document.body.addEventListener('mousecancel', this.indicatorEnd, false)
    },
    removeBodyEvent () {
      document.body.removeEventListener('mouseup', this.indicatorEnd)
      document.body.removeEventListener('mouseleave', this.indicatorEnd)
      document.body.removeEventListener('mousemove', this.indicatorMove)
      document.body.removeEventListener('mousecancel', this.indicatorEnd)
    },
    updateIndicatorX () {
      this.$nextTick(() => {
        if (this.model) {
          this.indicatorX = 53
          this.indicatorText = 'ON'
        } else {
          this.indicatorX = 4
          this.indicatorText = 'OFF'
        }
        this.indicator.style.transform = 'translateX(' + this.indicatorX + 'px)'
        this.indicator.style.WebkitTransform = 'translateX(' + this.indicatorX + 'px)'
      })
    },
    onListItemClick () {
      if (this.$parent.$el.classList.contains('obg-list-item')) {
        this.clickHandler()
      }
    }

  },
  computed: {
    model: {
      get () {
        return this.value
      },
      set (value) {
        this.$emit('input', value)
      }
    }
  },
  updated () {
    this.updateIndicatorX()
  },
  mounted () {
    this.indicator = this.$el.querySelector('.indicator')
    this.checkbox = this.$el.querySelector('input')
    this.$el.addEventListener('click', this.clickHandler, false)
    this.updateIndicatorX()
    this.min = 4
    this.max = 53
    this.indicatorX = 4
    this.$parent.$on('click', this.onListItemClick)
  },
  data () {
    return {
      indicatorText: 'ON',
      active: false
    }
  },
  props: {
    value: {
      required: true
    },
    val: {
    },
    disabled: Boolean
  }
}
</script>

<style lang="scss" scoped >
.container{
  &.obg-focus{
    .outer{
      box-shadow: inset 0 0 0 4px #ffffff;
    }
  }
  width:122px;
  display:block;
  height:45px;

  &.disabled{
    .area{
      position:relative;

      .indicator{
        color:#a9a9a9 !important;
        background-color:transparent !important;
      }
    }
  }

  &:not(.disabled).active{
  }

  input{
      display:none !important;
  }
  input:checked + .outer{
    .area{

      .indicator{
        transform: translateX(53px);
        -webkit-transform: translateX(53px);
      }
    }
  }
  input:not(:checked) + .outer{
    .area{

      .indicator{
        transform: translateX(2px);
        -webkit-transform: translateX(2px);
        background-color:transparent;
        color:#ffffff;
      }
    }
  }

  .outer{
    box-shadow: inset 0 0 0 1px #ffffff;
    width:100%;
    height:100%;
    border-radius:40px;
    display:flex;
    align-items:center;

    .area{
      margin:auto;
      width:100%;
      height:100%;
      position:relative;
      background-color:transparent;

      .indicator{
        position:absolute;
        color:#000000;
        text-align: center;
        text-indent: -4px;
        font-size:32px;
        top:4px;
        height:37px;
        width:65px;
        border-radius:40px;
        background-color:#ffffff;
      }
    }
  }
}

</style>
