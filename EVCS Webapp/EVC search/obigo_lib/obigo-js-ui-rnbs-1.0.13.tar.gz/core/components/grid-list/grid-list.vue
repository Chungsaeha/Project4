<template>
    <div class='obg-grid-list' >
        <div class='obg-grid-list-inner' >
			<slot></slot>
        </div>
    </div>
</template>

<script>
import IScroll from '../../features/iscroll'
/**
 * obg-grid-list
 * @class grid list
 * @classdesc components/grid-list
 * @param {number} [row=2]
 * @param {number} [col=4]
 *
 * @example
 * <obg-grid-list :row=3 :col=3 >
 *   <obg-grid-list-item >hello</obg-grid-list-item>
 *   <obg-grid-list-item >hello</obg-grid-list-item>
 *   <obg-grid-list-item >hello</obg-grid-list-item>
 *   <obg-grid-list-item >hello</obg-grid-list-item>
 *   <obg-grid-list-item >hello</obg-grid-list-item>
 * </obg-grid-list>
 */
export default {

  name: 'obg-grid-list',
  props: {
    col: {
      type: Number,
      default: 4
    },
    row: {
      type: Number,
      default: 2
    }
  },
  data () {
    return {
      width: 764,
      height: 330,
      padding: 0
    }
  },
  methods: {
    makePositions () {
      var itemCountInPage = this.col * this.row
      var len = this.$slots.default.length
      var realIdx = 0

      for (var i = 0; i < len; i++) {
        if (this.$slots.default[i].tag === undefined) {
          continue
        }
        var nowPage = Math.floor(realIdx / itemCountInPage)

        this.$slots.default[i].elm.style.width = ((this.width / this.col) - this.padding) + 'px'
        this.$slots.default[i].elm.style.height = ((this.height / this.row) - (this.padding * 2)) + 'px'

        this.$slots.default[i].elm.style.left = (nowPage * this.width) + ((realIdx % this.col) * (this.width / this.col)) + 'px'
        this.$slots.default[i].elm.style.top = Math.floor((realIdx % itemCountInPage) / this.col) * (this.height / this.row) + 'px'
        realIdx++
      }

      // scrollers의 width를 명시적으로  늘려줄 경우, scroller의 transition 시간을 0으로 세팅하고 바꿔줘야함.
      // scroll 동작이 끝나는 시점에 transitionDuration이 0이 아닌 시간으로 설정되 있을 수 있음.
      // 그렇게 되면 이 부분에서 width를 바꿀 때 에니매이션이 적용됨. 그려면 scroll.refresh가 호출 될때 정상적인 clientWidth값이 넘어오지 않게됨.
      // list 에서는 필요없음. scroller의 width나 height를 명시적으로 설정하지 않기 때문
      this.$el.firstChild.style.transitionDuration = '0ms'
      this.$el.firstChild.style.webkitTransitionDuration = '0ms'
      this.$el.firstChild.style.width = this.width * Math.ceil((realIdx / itemCountInPage)) + 'px'
    },
    refreshScroll () {
      if (this.$scroll) {
        let beforeTotalPage = this.$scroll.pages.length
        this.$scroll.refresh()
        let afterTotalPage = this.$scroll.pages.length
        if (beforeTotalPage !== afterTotalPage && this.zone3.children.length === 1 && this.zone3.children[0] === this.naviContainer) {   // update when total page number is changed
          this.makePageNavi()
        }
      } else {
        this.makeScroll()
      }
    },
    makeScroll () {
      if (this.$el.querySelectorAll('.obg-grid-list-inner > *').length === 0 || this.$slots.default === undefined || this.$slots.default.length === 0) {
        return
      }
      let opt = {
        probeType: 2,
        scrollY: false,
        scrollX: true,
        bounce: false,
        mouseWheel: false,
        // scrollbars: true,
        fadeScrollbars: true,
        // interactiveScrollbars: false,
        click: true,
        snap: true,
        disableMouse: !('onmousedown' in window),
        disablePointer: true,
        disableTouch: !('ontouchstart' in window)
      }
      this.makePositions()

      this.zone3 = this.$root.$el.querySelector('.obg-footer .zone-3')
      if (this.zone3 && this.zone3.children.length === 0) {
        this.$scroll = new IScroll(this.$el, opt)
        this.makePageNavi()
      } else {
        opt.scrollbars = true
        this.$scroll = new IScroll(this.$el, opt)
      }
      this.$scroll.on('scrollEnd', this.scrollEnd)
    },
    makePageNavi () {
      this.destroyDots()
      var pages = this.$scroll.pages.length
      let currentPage = this.$scroll.currentPage.pageX
      this.dots = []
      this.naviContainer = document.createElement('div')
      this.naviContainer.className = 'grid-navi-container'

      if (pages > 1) {
        for (var i = 0; i < pages; i++) {
          let dot = document.createElement('div')
          dot.className = 'dot'
          if (i === currentPage) {
            dot.classList.add('sel')
          }
          this.naviContainer.appendChild(dot)
          dot.addEventListener('click', this.changePage, false)
          dot.idx = i
          this.dots.push(dot)
        }
      }
      this.zone3.appendChild(this.naviContainer)
    },
    scrollEnd () {
      if (this.naviContainer && this.dots.length > 0) {
        this.naviContainer.querySelector('.sel').classList.remove('sel')
        this.dots[this.$scroll.currentPage.pageX].classList.add('sel')
      }
    },
    changePage (evt) {
      this.$scroll.goToPage(evt.target.idx, 0, 300)
    },
    destroyDots () {
      if (this.zone3 && this.naviContainer) {
        this.zone3.removeChild(this.naviContainer)
        this.naviContainer = undefined
      }
    }
  },
  updated () {
    this.makePositions()
    this.refreshScroll()
  },
  mounted () {
    this.makeScroll()
  },
  beforeDestroy () {
    if (this.$scroll) {
      this.$scroll.destroy()
      this.$scroll = undefined
    }
    this.destroyDots()
  }

}
</script>
<style lang='scss' scoped >
/*
@import '../../styles/common/colors.variables.scss';
*/
.obg-grid-list{
  /*margin: 0 auto;
  padding: 10px 0;*/
  position:relative;
	overflow:hidden;
}

.grid-navi-container{
  height:78px;
  width:100%;
  display:flex;
  align-items:center;
  justify-content:center;

  .dot {
    &.sel{
      background-color:rgb(34,34,38); /* color(grey-1); */
    }
    width:20px;
    height:20px;
    border-radius:50%;
    background-color:white;
    margin-left:10px;
    margin-right:10px;
  }
}
</style>


