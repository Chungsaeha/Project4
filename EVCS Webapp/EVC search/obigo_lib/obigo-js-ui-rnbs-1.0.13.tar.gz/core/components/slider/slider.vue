<template>
  <div
    class="obg-slider"
    :class="[mode + '-mode', { 'obg-slider-disabled': disabled }]"
    :style="{ 'width': sliderWidth + 'px'}"
  >
    <slot name="start"></slot>
    <div class="obg-slider-content" ref="content" @mousedown.prevent="onClickBar">
      <div class="obg-slider-runway" :style="{ 'border-top-width': barHeight + 'px' }" ></div>
      <div class="obg-slider-progress" :style="{ width: progress + '%', height: barHeight + 'px' }" ></div>
      <div
        class="obg-slider-thumb"
        :class="{'animate-scale': thumbScale}"
        ref="thumb"
        :style="{ left: progress + '%' }"
      >
        <span v-if="thumbLabel" class="obg-slider-current-value">{{progress}}</span>
      </div>
    </div>
    <slot name="end"></slot>
  </div>
</template>

<script type="text/babel">
  /**
   * @class slider
   * @classdesc components/slider
   * @param {slot} [slot='start']
   * @param {slot} [slot='end']
   * @param {number} [min=0]
   * @param {number} [max=100]
   * @param {number} [step=1]
   * @param {number} [value=0]
   * @param {number} [barHeight=5]
   * @param {number} [sliderWidth=500]
   * @param {boolean} [draggable=true]
   * @param {boolean} [disabled=false]
   * @param {event} [change]
   * @param {event} [input]
   *
   * @example
   * <obg-slider
   *  class="slider"
   *  v-model="model"
   *  :min="0"
   *  :max="100" @input="onInput" @change="onChange"
   *  ></obg-slider>
   */
  import draggable from '../../features/draggable'
  export default {
    name: 'obg-slider',
    props: {
      min: {
        type: Number,
        default: 0
      },
      max: {
        type: Number,
        default: 100
      },
      step: {
        type: Number,
        default: 1
      },
      disabled: {
        type: Boolean,
        default: false
      },
      value: {
        type: Number
      },
      barHeight: {
        type: Number,
        default: 1
      },
      draggable: {
        type: Boolean,
        default: true
      },
      focus: {
        type: Boolean,
        defalut: false
      },
      sliderWidth: {
        type: Number,
        default: 454
      },
      thumbLabel: {
        type: Boolean,
        default: false
      },
      thumbScale: {
        type: Boolean,
        default: true
      },
      mode: {
        type: String,
        default: 'slider'
      }
    },
    computed: {
      progress () {
        const value = this.value
        if (typeof value === 'undefined' || value === null || value === 0) return 0
        if (this.value >= this.max) {
          return 100
        } else if (this.value <= this.min) {
          return 0
        }
        return Math.floor((value - this.min) / (this.max - this.min) * 100)
      }
    },
    watch: {
      focus (isFocus) {
        if (isFocus) {
          this.$refs.thumb.classList.add('focus')
        } else {
          this.$refs.thumb.classList.remove('focus')
        }
      }
    },
    mounted () {
      const thumb = this.$refs.thumb
      const content = this.$refs.content
      this.stepCount = Math.ceil((this.max - this.min) / this.step)
      const getThumbPosition = () => {
        const contentBox = content.getBoundingClientRect()
        const thumbBox = thumb.getBoundingClientRect()
        return {
          left: thumbBox.left - contentBox.left,
          top: thumbBox.top - contentBox.top,
          contentBox: contentBox,
          thumbBox: thumbBox
        }
      }
      if (this.draggable) {
        let dragState = {}
        draggable(thumb, {
          start: (event) => {
            if (this.disabled) return
            const position = getThumbPosition()
            dragState = {
              thumbStartLeft: position.left,
              thumbStartTop: position.top,
              eventStartX: event.pageX
            }
          },
          drag: (event) => {
            const distance = Math.abs(event.pageX - dragState.eventStartX)
            if (this.disabled || distance < 10) return
            const contentBox = content.getBoundingClientRect()
            let thumbFactor = (this.$refs.thumb.getBoundingClientRect().width / 2) / contentBox.width
            const deltaX = event.pageX - contentBox.left - dragState.thumbStartLeft
            const newPosition = (dragState.thumbStartLeft + deltaX) - (dragState.thumbStartLeft + deltaX) % (contentBox.width / this.stepCount)
            thumbFactor = Number((thumbFactor / this.step).toFixed(1))
            let newProgress = newPosition / contentBox.width - thumbFactor

            if (newProgress < 0) {
              newProgress = 0
            } else if (newProgress > 1) {
              newProgress = 1
            }
            this.$emit('input', Math.round(this.min + newProgress * (this.max - this.min)))
          },
          end: () => {
            if (this.disabled) return
            this.$emit('input', this.value)
            dragState = {}
          }
        })
      }
    },
    methods: {
      onClickBar (event) {
        if (this.draggable && this.mode === 'slider') {
          const contentBox = this.$refs.content.getBoundingClientRect()
          const deltaX = event.pageX - contentBox.left
          let newProgress = Math.floor(this.max * deltaX / contentBox.width)
          if (newProgress < this.min) {
            newProgress = this.min
          } else if (newProgress > this.max) {
            newProgress = this.max
          }
          this.$emit('input', newProgress)
          event.stopPropagation()
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
/*
  @import '../../styles/common/colors.variables.scss';
  */
  .obg-slider {
    position: relative;
    display: flex;
    align-items: center;
    padding-right: 14px;
    height: inherit;
    & > * {
      display: flex;
      display: -webkit-box;
    }
    & *[slot=start] {
      margin-right: 12px;
    }
    & *[slot=end] {
      margin-left: 12px;
    }
    & > .obg-slider-content{
      position: relative;
      flex: 1;
      & > .obg-slider-runway{
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        left: 0;
        right: -15px;
        border-top-color: rgb(161,162,179); /* color(grey-3); */
        border-top-style: solid;
      }
      & > .obg-slider-thumb{
        background-color: #ffffff; /* color(white); */
        position: absolute;
        left: 0;
        top: -7px;
        cursor: move;
        display: flex;
        justify-content: center;
        align-items: center;
        &.animate-scale{
          &:active{
            & > span{
              font-size:20px;
            }
          }
        }
        & > span {
          font-size:14px;
        }
      }
      & > .obg-slider-progress {
        position: absolute;
        display: block;
        top: 50%;
        transform: translateY(-50%);
        width: 0;
        &:before{
          position: absolute;
          top: -3px;
          right: 0px;
          display: block;
          content: '';
          width: inherit;
          height: 7px;
        }
      }
    }
    &.range-mode{
      & .obg-slider-content {
        & > .obg-slider-runway{
        }
        & > .obg-slider-progress, & >.obg-slider-runway {
          display:none;
        }
        & > .obg-slider-thumb {
          background-color: #ffffff; /* color(white); */
          width: 67px;
          height: 37px;
          border-radius: 40px;
          top: -19px;
          box-shadow: none;
          margin-left: 1px;
          & > span {
            font-size:32px;
          }
          &:active{
            background-color: #14385c;
            color: #ffffff;
          }
          /*&.obg-focus {
            background-color: #1c1c1c;
            color: #ffffff;
            border: 4px solid #ffffff;
          }*/
        }
      }
    }
    &.obg-slider-disabled {
      user-select: none;
      pointer-events: none;
      opacity: 0.3;
    }
  }

  @keyframes thumb-scale {
    0% {
      transform: scale(0.7)
    }
    100% {
      transform: scale(1)
    }
  }
</style>
