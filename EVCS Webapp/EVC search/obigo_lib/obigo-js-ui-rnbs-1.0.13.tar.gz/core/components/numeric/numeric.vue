<template>
  <div
    class="obg-numeric"
    :style="{ width: width + 'px', height: height + 'px' }"
    :delimiter="delimiter"
    data-type="focus-control-able"
  >
    <div
      ref="up"
      class="obg-numeric-button"
      :style="{ width: width + 'px' }"
      @click="valueUp"
    ><div class="arrow up"></div></div>
    <div
      ref="number"
      class="number"
      :style="{ width: width + 'px' }"
    >
      {{padDigits}}
      </div>
    <div
      ref="down"
      class="obg-numeric-button"
      :style="{ width: width + 'px' }"
      @click="valueDown"
    ><div class="arrow down"></div></div>
    <div
      class="delimiter"
      ref="delimiter"
      v-show="showDelimiter"
      :style="{ top: delimiterTop +'px', left: delimiterLeft + 'px' }"
    >
      {{delimiter}}
      </div>
  </div>
</template>

<script>
  /**
   * @class numeric
   * @classdesc components/numeric
   * @param {number} [min=0]
   * @param {number} [max=99]
   * @param {number} [step=1]
   * @param {number} [value=0]
   * @param {number} [width=150]
   * @param {number} [height=300]
   * @param {boolean} [disable=false]
   * @param {boolean} [loop=true]
   * @param {boolean} [showDelimiter=true]
   * @param {number} [placeValue=2]
   * @param {string} [delimiter=':']
   *
   * @example
   * <obg-numeric
   *    :loop="true"
   *    :min="1"
   *    :max="31"
   *    delimiter="/" @input="onInputDay"
   *    v-model="dayModel">
   * </obg-numeric>
   */
  import longpress from '../../features/longPress'
  import focusControlMixin from '../../mixins/focus-control'

  export default {
    name: 'obg-numeric',
    mixins: [focusControlMixin],
    props: {
      min: {
        type: Number,
        default: 0
      },
      max: {
        type: Number,
        default: 99
      },
      step: {
        type: Number,
        default: 1
      },
      disabled: {
        type: Boolean,
        default: false
      },
      value: {
        type: Number,
        default: 0
      },
      width: {
        type: Number,
        default: 150
      },
      height: {
        type: Number,
        default: 300
      },
      delimiter: {
        type: String,
        default: ':'
      },
      showDelimiter: {
        type: Boolean,
        default: true
      },
      placeValue: {
        type: Number,
        default: 2
      },
      loop: {
        type: Boolean,
        default: true
      }
    },
    computed: {
      delimiterTop () {
        return -(this.height / 2) + -(this.delimiterHeight / 2)
      },
      delimiterLeft () {
        return this.width - this.delimiterWidth / 2
      },
      padDigits () {
        return Array(Math.max(this.placeValue - String(this.digits).length + 1, 0)).join(0) + this.digits
      }
    },
    watch: {
      value (val) {
        if (val < this.min || val > this.max) return
        this.digits = val
      }
    },
    mounted () {
      const up = this.$refs.up
      const down = this.$refs.down
      longpress(up, {
        counter: () => {
          this.valueUp()
        },
        end: () => {
          this.onInput(this.digits)
        }
      })
      longpress(down, {
        counter: () => {
          this.valueDown()
        },
        end: () => {
          this.onInput(this.digits)
        }
      })
      this.$nextTick(() => {
        let elementOffset = this.$el.getBoundingClientRect()
        let numberOffset = this.$refs.number.getBoundingClientRect()
        this.offsetTop = elementOffset.top
        this.offsetLeft = elementOffset.left
        this.numberHeight = numberOffset.height
        if (this.showDelimiter) {
          let delimiterOffset = this.$refs.delimiter.getBoundingClientRect()
          this.delimiterHeight = delimiterOffset.height
          this.delimiterWidth = delimiterOffset.width
        }
      })
    },
    data () {
      return {
        digits: (this.value < this.min) ? this.min : this.value,
        focus: false,
        focusIndex: 0,
        offsetTop: 0,
        numberHeight: 0,
        delimiterOffsetTop: 0,
        delimiterWidth: 1,
        delimiterHeight: 1,
        hardkeyCodes: this.$hardkey.getCodes()
      }
    },
    methods: {
      valueDown () {
        this.digits = this.digits - this.step
        if (this.digits < this.min) this.digits = (this.loop) ? this.max : this.min
        this.$emit('input', this.digits)
      },
      valueUp () {
        this.digits = this.digits + this.step
        if (this.digits > this.max) this.digits = (this.loop) ? this.min : this.max
        this.$emit('input', this.digits)
      },
      onInput (val) {
        this.$emit('input', val)
      },
      onControlIn () {
        this.$el.classList.remove('obg-focus')
        this.$refs.up.classList.add('obg-focus')
      },
      onRotate () {
        if (this.focusIndex === 0) {
          this.$refs.up.classList.remove('obg-focus')
          this.$refs.down.classList.add('obg-focus')
          this.focusIndex = 1
        } else {
          this.$refs.up.classList.add('obg-focus')
          this.$refs.down.classList.remove('obg-focus')
          this.focusIndex = 0
        }
      },
      onRotateClick () {
        if (this.focusIndex === 0) {
          this.valueUp()
        } else {
          this.valueDown()
        }
        this.focusIndex = 0
        this.$el.classList.add('obg-focus')
      }
    }
  }
</script>
<style lang='scss' scoped>
/*
  @import '../../styles/common/colors.variables';
  */
  .obg-numeric {
    display: inline-block;
    position: relative;
    & > .number{
      position: relative;
      font-size: 4em;
      text-align: center;
      color: #ffffff; /* color(white); */
      display: block;
      height:100px;
      background-color: rgb(25, 25, 25);
    }
    & > .obg-numeric-button{
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: rgb(25, 25, 25);
      color: #ffffff; /* color(white); */
      font-size: 30px;
      height:100px;
      &:active{
        border-color: #ffffff; /* color(white); */
        box-shadow: none;
        color: #ffffff; /* color(white); */
        background-color: #14385c; /* color(secondary); */
      }
      &.obg-focus{
        border: 4px solid #ffffff; /* color(white); */
      }
      & > .arrow {
        &.up {
          transform: rotate(45deg);
          margin-top: -20px;
          margin-left: -20px;
          &:before{
            content: '';
            border: 5px solid #fff;
            display: block;
            height: 20px;
            float: left;
            margin-left: 17px;
            margin-top: 10px;
            border-radius: 5px;
          }
          &:after{
            content: '';
            top: 10px;
            left: 17px;
            border: 5px solid #fff;
            display: block;
            width: 20px;
            position: relative;
            border-radius: 5px;
          }
        }
        &.down{
          transform: rotate(225deg);
          margin-right: -14px;
          margin-top: 14px;
          &:before{
            content: '';
            border: 5px solid #fff;
            display: block;
            height: 20px;
            float: left;
            margin-left: 17px;
            margin-top: 10px;
            border-radius: 5px;
          }
          &:after{
            content: '';
            top: 10px;
            left: 17px;
            border: 5px solid #fff;
            display: block;
            width: 20px;
            position: relative;
            border-radius: 5px;
          }
        }
      }
    }
    & > .delimiter{
      position:relative;
      font-size: 4em;
      color: rgba(255,255,255,0.7);;
      display:inline-block;
      z-index: 1;
      height:100px;
    }
    &.obg-focus{
      &:before{
        border: 4px solid #fff;
        content: '';
        position: absolute;
        width: 100%;
        height: 100%;
        z-index: 1;
        box-sizing: border-box;
      }
    }
  }
</style>
