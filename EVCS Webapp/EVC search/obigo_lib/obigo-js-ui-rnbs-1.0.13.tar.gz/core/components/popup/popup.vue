<template>
    <div class="overlay" @click.stop='clickOverlay' >
        <div class="popup" @click.stop >
          <div class="title" v-if='title' >
            <div class='title-inner' >{{title}} </div>
          </div>
          <div class='content-area' id='component-content' v-if='typeof content === "object"' ><div class='content-inner' >{{content}}</div></div>
          <div class='content-area text' id='text-content'  v-if='typeof content === "string"'>{{content}}</div>
          <div class="btn-area" v-if='buttons && buttons.length > 0' >
              <button v-for="btn in buttons" :style="getBtnWidth()" @click="btn.onClick" @touchstart='down' @touchend='up' @touchcancel='up' >{{btn.label}}</button>
          </div>
        </div>
    </div>
</template>

<script>
import Vue from 'vue'
export default {
  name: 'obg-popup',
  methods: {
    down (e) {
      e.target.classList.add('active')
    },
    up (e) {
      e.target.classList.remove('active')
    },
    close () {
      let contentData
      let titleData
      if (this.componentContent) {
        contentData = this.componentContent.$children[0].$data
        this.componentContent.$destroy()
      }
      if (this.componentTitle) {
        titleData = this.componentTitle.$children[0].$data
        this.componentTitle.$destroy()
      }
      this.$root.$destroy()
      this.$root.$el.parentNode.removeChild(this.$root.$el)
      this.onClose(contentData, titleData)
    },
    getBtnWidth () {
      return {
        width: (100 / this.buttons.length) + '%'
      }
    },
    clickOverlay (e) {
      if (this.buttons === undefined || this.buttons.length === 0) {
        clearTimeout(this.autoCloseTimer)
        this.close()
      }
    }
  },
  data () {
    return {
      timeout: 5000
    }
  },
  props: {
    buttons: {
      type: Array
    },
    title: {
      type: [String, Object]
    },
    content: {
      type: [String, Object]
    },
    height: {
      type: Number,
      default: 250
    },
    width: {
      type: Number,
      default: 518
    },
    onOpen: {
      type: Function,
      default: () => {}
    },
    onClose: {
      type: Function,
      default: () => {}
    }
  },
  mounted () {
    this.$el.firstChild.style.width = this.width + 'px'

    var contentHeight = this.height - 2 // border top, bottom 각각 1픽셀
    if (this.title) {
      contentHeight = contentHeight - 66  // title height
    }
    if (this.buttons && this.buttons.length > 0) {
      contentHeight = contentHeight - 60  // button area height
    }

    if (!this.buttons || this.buttons.length === 0) {
      this.autoCloseTimer = setTimeout(this.close, this.timeout)
    }
    if (typeof this.content === 'object') {
      this.$el.querySelector('#component-content').style.height = contentHeight + 'px'
      this.$el.firstChild.style.height = this.height + 'px'
      let props = this.content.props || {}
      props.height = this.height
      props.width = this.width
      this.componentContent = new Vue({
        el: this.$el.querySelector('.content-inner'),
        render: h => h(this.content.component, {props})
      })
    } else {
      this.$el.firstChild.style.minHeight = this.height + 'px'  // text content일 경우, text 길이에 따라 자연스럽게 높이가 변할수 있게 min-height속성을 변경
    }

    if (typeof this.title === 'object') {
      let props = this.title.props || {}
      props.height = this.height
      props.width = this.width
      this.componentTitle = new Vue({
        el: this.$el.querySelector('.title-inner'),
        render: h => h(this.title.component, {props})
      })
    }

    this.$root.closePopup = this.close
    this.onOpen()
  }
}
</script>

<style lang="scss" scoped >
.overlay{
  position:fixed;
  width:100%;
  height:100%;
  top:0;
  left:0;
  z-index:400;
  background-color:rgba(0, 0, 0, 0.4);
  display:flex;
  align-items:center;
  justify-content:center;
  color:white;

  .popup{
      flex:none;
      /*
      width:518px;
      min-height:200px;
      */
      border:1px solid #737480;
      font-size:32px;
      flex-direction:column;
      display:flex;
      background:#2a2a2a;
      .title{
        .title-inner{
          padding-left:10px;
          padding-right:10px;
          font-size:32px; line-height:66px;
          text-align:center;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          height:66px;
        }
      }
      .content-area{
          flex:1;
          overflow: hidden;

          &.text{
            line-height:39px;
            margin:16px 23px;
            text-align:center;
            white-space:pre-wrap;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 5; /* 라인수 */
            -webkit-box-orient: vertical;
            word-wrap:break-word;
          }
      }
      .btn-area{
          height:60px;
          button{
              margin:0;
              background:none;
              color:white;
              border-radius:unset;
              border:none;
              border-top:1px solid rgb(161,162,179);     /* grey-3 */
              border-right:1px solid rgb(161,162,179);   /* grep-3 */
              box-shadow:none;
              height:60px;
              font-size:32px;
              line-height:52px;
              &:last-child{
                  border-right:none;
              }
              &.focus{
                box-shadow: inset 0 0 0 4px #ffffff;
              }
              &:active, &.active{
                  background-color:#14385c;         /* secondary */
              }
          }
      }
  }
}
</style>
