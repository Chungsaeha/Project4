<template>
    <div class="overlay" >
        <div class="popup" @click.stop >
          <div class='pop-contents' >
            <div class="title" >
                {{title}}
            </div>
            <div class="content" >
                <div  class='text-content' >{{content}}</div>
                <div class='progress-area' >
                  <div class='progress-bar' >
                    <div class='bar-outline' >
                      <div class='bar-gauge' :style='{width:barWidth+"%"}'  ></div>
                    </div>
                  </div>
                  <div class='progress-text'>
                    {{barWidth}}%
                  </div>
                </div>
            </div>
          </div>
          <div class="btn-area" v-if='buttons &&  buttons.length != 0' >
              <button @click="btn.onClick" v-for="btn in buttons" :style="getBtnWidth()" @touchstart='down' @touchend='up' @touchcancel='up' >{{btn.label}}</button>
          </div>
        </div>
    </div>
</template>

<script>
export default {
  name: 'obg-progress-popup',
  methods: {
    down (e) {
      e.target.classList.add('active')
    },
    up (e) {
      e.target.classList.remove('active')
    },
    close () {
      this.$root.$destroy()
      this.$root.$el.parentNode.removeChild(this.$root.$el)
    },
    updateProgress (width) {
      this.barWidth = width
    },
    getBtnWidth () {
      return {
        width: (100 / this.buttons.length) + '%'
      }
    }
  },
  data () {
    return {
      barWidth: 0
    }
  },
  props: {
    buttons: {
      type: Array
    },
    title: {
      type: String
    },
    content: {
      type: String
    },
    progress: {
      type: Number,
      validator: function (value) {
        return value >= 0 && value <= 100
      }
    }
  },
  mounted () {
    if (this.progress !== undefined) {
      this.updateProgress(this.progress)
    }
    this.$root.closePopup = this.close
    this.$root.updateProgress = this.updateProgress
  }
}
</script>

<style lang="scss" scoped >
/*
@import '../../styles/common/colors.variables';
*/
.overlay{
    position:fixed;
    width:100%;
    height:100%;
    top:0;
    left:0;
    z-index:400;
    background-color:rgba(0, 0, 0, 0.4);
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;

    .popup{
        flex:none;
        width:518px;
        min-height:200px;
        border:1px solid #737480;
        background:#2a2a2a;
        flex-direction:column;
        display:flex;

        .pop-contents{
          text-align:center; padding-bottom:10px;
          .title{
              font-size:32px; line-height:66px;
              text-align:center;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
          }
          .content{
              padding:10px 10px;
              flex:1;
              margin:16px 23px;
              line-height:39px;
              .text-content{
                  font-size:32px;
                  flex:1;
                  text-align:center;
                  white-space:pre-wrap;

                  overflow: hidden;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-line-clamp: 4; /* 라인수 */
                  -webkit-box-orient: vertical;
                  word-wrap:break-word;
              }
              .progress-area{
                margin-top:10px;
                display:flex;
                font-size:18px;
                flex-direction:row;
                justify-content:center;
                align-items:center;
                height:30px;
                & > div{
                  margin-left:4px;
                  margin-right:4px;
                }

                .progress-bar{
                  width:90%;
                  .bar-outline{
                    border:1px solid #737480;
                    height:20px;
                    background-color:#595959;

                    .bar-gauge{
                      height:100%;
                      background-color:#00d4ff;
                    }
                  }
                }
                .progress-text{
                  width:10%;
                }
              }
          }
        }
        .btn-area{
            height:60px;
            button{
                width:100%;
                margin:0;
                background:none;
                color:white;
                border:none;
                border-top:1px solid rgb(161,162,179); /* color(grey-3); */
                border-right:1px solid rgb(161,162,179); /* color(grey-3); */
                box-shadow:none;
                height:60px;
                font-size:32px;
                line-height:52px;
                &:last-child{
                    border-right:none;
                }
                &.focus{
                  box-shadow: inset 0 0 0 4px #ffffff; /* color(white); */
                }
                &:active, &.active{
                    background-color:#14385c; /* color(secondary); */
                }
            }
        }
    }
}
</style>
