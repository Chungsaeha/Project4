<template>
  <button
    class="obg-button"
    :class="['obg-button-' + type, 'obg-button-' + size, {
      'is-disabled': disabled,
      'is-icon': icon || $slots.icon,
      'icon-only': iconOnly
    }]"
    @click.stop="handleClick"
    :disabled="disabled">
    <span class="obg-button-icon" v-if="icon || $slots.icon">
      <slot name="icon">
        <i v-if="icon" :class="'obg-icon-' + icon"></i>
      </slot>
    </span>
    <label class="obg-button-text"><slot></slot></label>
  </button>
</template>

<script>
/**
 * @class button
 * @classdesc components/button
 * @param {string} [type=default | round | square | squareroundlist | squareroundoutline | squareround | footer]
 * @param {boolean} [disabled=false]
 * @param {string} [icon]
 * @param {slot} [slot] label
 * @param {slot} [icon] icon
 *
 * @example
 * <obg-button icon="back" type="default">button</obg-button>
 * <obg-button type="default">
 *    <i class="obg-icon-back" slot="icon" />
 *    button
 * </obg-button>
 */
import {triggerBodyClickEvent} from '../../utils/event'

export default {
  name: 'obg-button',
  methods: {
    handleClick (evt) {
      triggerBodyClickEvent(evt)
      this.$emit('click', evt)
    }
  },
  computed: {
    iconOnly () {
      if ((this.icon || this.$slots.icon) && typeof this.$slots.default === 'undefined') {
        return true
      }
      return false
    }
  },
  props: {
    icon: String,
    disabled: Boolean,
    type: {
      type: String,
      default: 'default',
      validator (value) {
        return ['default', 'round', 'square', 'squareroundlist', 'squareroundoutline', 'squareround', 'footer'].indexOf(value) > -1
      }
    },
    size: {
      type: String,
      default: 'normal',
      validator (value) {
        return [
          'small',
          'normal',
          'large'
        ].indexOf(value) > -1
      }
    }
  }
}
</script>

<style lang="scss">
/*
  @import '../../styles/common/colors.variables.scss';
  */
  .obg-button{
    position: relative;
    display: flex;
    color: #ffffff;   /* white */
    background-color: transparent;
    outline: none;
    user-select: none;
    align-items: center;
    justify-content: center;
    .obg-button-icon{
      display:flex;
      justify-content: center;
      margin:auto;
    }
    &.icon-only{
      & > span {
        margin: 0 auto;
      }
      & > label {
        flex: 0;
        padding: 0 !important;
      }
    }
    &.is-icon{
      min-height:55px;
      /*& > .obg-button-text {
        max-width: 160px;
      }*/
    }
    &.obg-button-default, &.obg-button-round, &.obg-button-square,
    &.obg-button-squareroundlist, &.obg-button-squareroundoutline,
    &.obg-button-squareround{
      display:block;
      &.icon-only > label.obg-button-text {
        display: none;
      }
      &.is-icon > .obg-button-text {
        padding: 0 10px 0 10px;
      }
      /*& > .obg-button-text{
        line-height:24px;
      }*/
    }
    &.obg-button-square{
      background-color: rgb(34,34,38);     /* color(grey-1); */
      &:before{
        position: absolute;
        left:0; bottom:0;
        content: '';
        display: none;
        width: 100%;
        height: 5px;
      }
      &:active, &.active{
        -webkit-transform: scale(0.85);
        transform: scale(0.85);
      }
      &.select{
        &:before {
          display: block;
        }
        .obg-button-text{
            color: #ffffff;       /* color(white); */
        }
      }
    }
    &.obg-button-squareroundoutline{
      background-color: rgb(34,34,38);     /* color(grey-1); */
      &:active, &.active{
        -webkit-transform: scale(0.85);
        transform: scale(0.85);
      }
      .obg-button-icon{
        width: 100%;
        /*width: 182px;*/
      }
    }
    &.obg-button-squareroundlist{
      box-shadow: none;
      &:before{
        position: absolute;
        top: 0;
        left: 0;
        display: block;
        content: '';
        width: 97px;
        height: 55px;
        background-color: rgb(34,34,38);     /* color(grey-1); */
        border-radius: 55px;
      }
      &:active, &.active{
        &:before{
          -webkit-transform: scale(0.85);
          transform: scale(0.85);
        }
        .obg-button-icon, .obg-button-text{
          -webkit-transform: scale(0.85);
          transform: scale(0.85);
        }
      }
      &.select{
        &:before{
          background-color: #ffffff /* color(white) */ !important;
        }
        .obg-button-text{
          color: #000000; /* color(black); */
        }
      }
      .obg-button-icon, .obg-button-text{
        position: relative;
        z-index: 10;
      }
    }
    &.obg-button-round{
      &:before{
        position: absolute;
        top: 4px;
        left: 4px;
        display: block;
        content: '';
        background-color: rgb(34,34,38);     /* color(grey-1); */
        box-shadow: inset 0 0 0 2px rgb(161,162,179) /* color(grey-3) */, 0 0 5px #000000; /* color(black); */ 
      }
      &:active, &.active{
        &:before{
          -webkit-transform: scale(0.85);
          transform: scale(0.85);
        }
        .obg-button-icon {
          -webkit-transform: scale(0.85);
          transform: scale(0.85);
        }
      }
      /*&.obg-focus{
        background-color: transparent;
        box-shadow: inset 0 0 0 4px color(white);
        .obg-button-icon{
          filter: none;
        }
      }*/
      &.select{
        &:before{
          background-color: #ffffff /* color(white) */ !important;
        }
        .obg-button-icon {
          filter: invert(100%) !important;
        }
      }
      .obg-button-icon,.obg-button-text{
        position: relative;
        z-index: 10;
      }
    }
    &.obg-button-squareround{
      background-color: rgb(34,34,38);     /* color(grey-1); */
      &:active{
        -webkit-transform: scale(0.85);
        transform: scale(0.85);
      }
      &.is-icon .obg-button-text{
        margin-top: -10px;
        font-size: 20px;
      }
    }
    & > .obg-button-text {
      display:block;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      word-wrap: normal;
      max-width: 400px;
      flex:1;
      padding: 0 10px 0 10px;
      line-height: 150%;
    }
  }

</style>
