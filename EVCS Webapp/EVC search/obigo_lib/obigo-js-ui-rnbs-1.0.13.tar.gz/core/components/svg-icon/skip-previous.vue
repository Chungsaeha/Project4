<template>
    <svg viewBox="0 0 24 24">
        <path d='M6 6h2v12H6zm3.5 6l8.5 6V6zz' fill='#ffffff' />
    </svg>
</template>

<script>
    export default{
        props:['fill'],
        name:'icon-skip-previous',
    }
</script>
<style scoped>
    svg{
        display: inline-block;
        height: 40px;
        width: 40px;
        margin: 6px 7px 6px 6px;
    }
</style>
