<template>
    <svg viewBox="0 0 24 24">
        <path d='M8 5v14l11-7z' fill='#ffffff' />
    </svg>
</template>

<script>
    export default{
        props:['fill'],
        name:'icon-play-arrow',
    }
</script>
<style scoped>
    svg{
        display: inline-block;
        height: 40px;
        width: 40px;
        margin: 6px 7px 6px 6px;
    }
</style>
