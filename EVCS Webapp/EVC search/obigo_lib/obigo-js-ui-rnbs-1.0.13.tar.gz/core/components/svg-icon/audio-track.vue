

<template>
    <svg viewBox="0 0 24 24">
        <path d='M12 3v9.28c-.47-.17-.97-.28-1.5-.28C8.01 12 6 14.01 6 16.5S8.01 21 10.5 21c2.31 0 4.2-1.75 4.45-4H15V6h4V3h-7z'   fill='#ffffff' />
    </svg>
</template>

<script>
    export default{
        props:['fill'],
        name:'icon-audio-track',
    }
</script>
<style scoped>
    svg{
        display: inline-block;
        height: 40px;
        width: 40px;
        margin: 6px 7px 6px 6px;
    }
</style>
