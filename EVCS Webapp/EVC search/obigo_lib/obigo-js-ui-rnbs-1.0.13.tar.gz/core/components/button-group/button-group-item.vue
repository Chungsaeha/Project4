<template>
  <button
    class="obg-button-group-item"
    :class="[iconPosition, {
      'obg-button-group-current': currentIndex === $parent.currentIndex,
      'obg-button-group-icon': icon || $slots.icon,
      'disabled': disabled,
      'icon-only': !($slots.default)
    }]"
    @click.stop="onItemClick"
    @touchstart="onPressItem" @touchend="onReleaseItem"
  >
    <span
      class="obg-button-group-icon"
       v-if="icon || $slots.icon">
      <slot name="icon">
        <i v-if="icon" :class="'obg-icon-' + icon"></i>
      </slot>
    </span>
    <label class="obg-button-group-text"><slot></slot></label>
  </button>
</template>

<script>
/**
 * @class button-group-item
 * @classdesc components/button-group-item
 * @param {boolean} [disabled=false]
 * @param {string} [icon]
 * @param {string} [iconPosition=top] top | left
 * @param {boolean} [selected]
 * @param {slot} [slot] label
 * @param {slot} [icon] icon
 *
 * @example
 * <obg-button-group-item icon='more' iconPosition='top' @click ='onClick' selected>
 *   button1
 * </obg-button-group-item>
 */
import { childMixin } from '../../mixins/multi-items'

export default {
  name: 'obg-button-group-item',
  mixins: [childMixin],
  props: {
    icon: String,
    iconPosition: {
      type: String,
      default: 'top',
      validator (value) {
        return [
          'top',
          'left'
        ].indexOf(value) > -1
      }
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    onPressItem (e) {
      e.currentTarget.classList.add('active')
    },
    onReleaseItem (e) {
      e.currentTarget.classList.remove('active')
    }
  }
}
</script>

<style lang="scss">
  @import '../../styles/common/colors.variables';
  .obg-button-group-item{
    position: relative;
    display: flex;
    width: 145px;
    height: 60px;
    border-radius: 30px;
    border: 2px solid transparent;
    background:none;
    color: color(white);
    font-size: 20px;
    outline: none;
    user-select: none;
    align-items: center;
    justify-content: center;
    &.obg-focus {
      &:before{
        content:'';
        position:absolute;
        width:145px;
        height:60px;
        border: 4px solid color(white);
        display:block;
      }
    }
    &.obg-button-group-icon {
      &.top {
        display:block;
        &:before{
          margin-top:-4px;
        }
        & > .obg-button-group-icon{
          display: flex;
          height: 32px;
          justify-content: center;
          align-items: center;
          & > i {
            display:block;
          }
          & > svg{
            height:32px;
          }
        }
        & > .obg-button-group-text{
          display:block;
          text-align: center;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          padding: 0 10px 0 10px;
          line-height: 24px;
          margin: 0 auto;
        }
      }
      &.left {
        & > .obg-button-group-icon{
          display: flex;
          justify-content: center;
          align-items: center;
          & > i {
            width: 55px;
            height: 55px;
            display: inline-block;
            transform: scale(0.6);
            -webkit-transform: scale(0.6);
          }
        }
        & > .obg-button-group-text{
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          width: 90%;
        }
      }
      &.icon-only{
        & > .obg-button-group-icon{
          height: 56px;
        }
        & > .obg-button-group-text{
          display:none;
        }
      }
    }
    &:active, &.active{
      border:2px solid color(white);
      background: color(secondary);
    }
    &.focus{
      color:color(white);
      box-shadow:none;
      border:2px solid color(white);
    }
    &.obg-button-group-current{
      border: 2px solid  #7b7b7b;
      background-color:  #7b7b7b;
      &:active, &.active{
        border-color: color(white);
        background: color(secondary);
      }
    }
    & > .obg-button-group-text{
      display:block;
      text-align: center;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      padding: 0 10px 0 10px;
      margin: 0 auto;
    }
    &.disabled{
      opacity:0.3;
      pointer-events: unset;
      &.active, &:active{
        border:none;
        background: none;
      }
    }

  }


</style>
