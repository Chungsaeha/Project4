import spinner from './spinner'
export default spinner
