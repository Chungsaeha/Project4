<template>
  <div class='obg-dialog' v-if='dialogShow' >
    <div class='header' >
      <slot name='header'></slot>
    </div>
    <div class='content' >
      <slot name='content' ></slot>
    </div>
    <div class='footer' >
      <slot name='footer' >
      </slot>
      <div class='footer-btn' v-if='isDefaultFooter()' >
        <obg-button @click='close' class='close-btn' type='round' >
          <i class="obg-icon-close" slot="icon" ></i>
        </obg-button>
      </div>
    </div>
  </div>
</template>

<script>
/**
 * @class dialog
 * @classdesc components/dialog
 * @param {boolean} [show=false] - show/hide status
 * @param {string} [title='']
 * @param {slot} header - html for header slot
 * @param {slot} content - html for content slot
 * @param {slot} footer - html for footer slot<br/>if not define, default footer html that only one button to close is generated
 *
 * @example
 * <obg-dialog title='dialog title' >
 *  <div >dialog content</div>
 * </obg-dialog>
 */
import button from '../button'
export default {
  name: 'obg-dialog',
  components: {
    'obg-button': button
  },
  methods: {
    close () {
      this.$emit('close')
    },
    isDefaultFooter () {
      return this.$slots.footer === undefined
    }
  },
  computed: {
    dialogShow: {
      get: function () {
        return this.show
      },
      set: function (newVal) {
        this.show = newVal
      }
    }
  },
  mounted () {
    console.log(this)
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    show: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="scss" scoped>
.obg-dialog{
  background-color:rgba(0, 0, 0, 0.74);
  position:absolute;
  display:flex;
  z-index:400;
  top:0;
  bottom:0;
  right:0;
  left:0;
  flex-direction:column;
  justify-content:center;
  align-items:stretch;
  .header{
    min-height:57px;
    h1{
      margin:0 auto; width:90%; font-size:38px; text-align:center; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; word-wrap:normal;
      height:57px; line-height:165%;
    }
  }
  .content{
    flex:1;
    overflow:hidden;
  }
  .footer{
    height:78px;
    display:flex;
    justify-content:center;
    align-items:center;
    .footer-btn{
      .close-btn{
      /*
        border-radius:40px;
        width:140px;
        border:1px solid #898989;
        box-shadow:none;
        */
      }

    }
  }
}


</style>
