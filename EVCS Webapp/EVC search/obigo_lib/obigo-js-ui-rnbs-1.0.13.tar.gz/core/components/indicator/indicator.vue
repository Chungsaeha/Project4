<template>
  <div
    class="obg-indicator"
    :style="{width: width + 'px'}"
  >
    <div
      v-for="n in count"
      class="dot-wrapper"
      @click="onClick"
      :index="n - 1"
    >
      <i
        class="dot"
        :class="{'selected': (model === n - 1)}" />
    </div>
  </div>
</template>

<script>
  /**
   * @class indicator
   * @classdesc components/indicator
   * @param {number} [width=210]
   * @param {number} [count=3] required
   * @param {number} [value=0]
   *
   * @example
   *  <obg-indicator :count="3" :width="300">
   *  </obg-indicator>
   */
  export default{
    name: 'obg-indicator',
    props: {
      width: {
        type: Number,
        default: 210
      },
      count: {
        type: Number,
        default: 3,
        required: true
      },
      value: {
        type: Number,
        default: 0
      }
    },
    computed: {
      model: {
        get () {
          return this.value
        },
        set (value) {
          this.$emit('input', value)
        }
      }
    },
    methods: {
      onClick (e) {
        let index = e.currentTarget.getAttribute('index')
        this.model = Number(index)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .obg-indicator{
    position: relative;
    display:flex;
    height:30px;
    justify-content: center;
    align-items: center;
    & > .dot-wrapper {
      flex: 1;
      display:flex;
      justify-content: center;
      align-items: center;
      & > .dot {
        display: block;
        width: 21px;
        height: 21px;
        background-color: #979797;
        border-radius: 50%;
        &:active {
          & > .dot{
            background-color: #5e5e5e;
          }
        }
        &.selected{
          background-color: #0078f0;
        }
      }
    }
  }

</style>
