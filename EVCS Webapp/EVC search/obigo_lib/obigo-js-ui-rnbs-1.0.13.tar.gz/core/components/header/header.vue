<template>
    <div class="obg-header">
        <div class="obg-header-column">
          <slot name="s1"></slot>
        </div>
        <div class="obg-header-column s2">
          <span v-if="title">{{title}}</span>
          <slot name="s2" v-else></slot>
        </div>
        <div class="obg-header-column">
          <slot name="s3"></slot>
        </div>
    </div>
</template>

<script>
export default {
  name: 'obg-header',
  props: {
    title: {
      type: String,
      default: null
    }
  }
}
</script>

<style lang="scss">
  .obg-header{
    width: 100%;
    height: 57px;
    display: flex;
    align-items: center;
    background: rgb(0, 0, 0);
    font-family:'OpenSans-Semibold';
    font-size: 28px;
    .obg-header-column{
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex: 1 1 0%;
      &.s2{
        flex:3;
      }
    }
  }
</style>
