<template>
  <label class="obg-radio" :class="{disable: disabled, focus: focus}">
    <input type="radio" v-model="model"  @click.stop  :value="val" :disabled="disabled">
    <div></div>
  </label>
</template>

<script>
  /**
   * @class radio
   * @classdesc components/radio
   * @param {any} [v-model]
   * @param {number} [val] required
   * @param {number} [value] required
   * @param {boolean} [focus=false]
   * @param {boolean} [disabled=false]
   * @param {event} [input]
   *
   * @example
   * <obg-radio
   *  v-model="model"
   *  :val="1st" @input="onInput"
   *  ></obg-radio>
   *  <obg-radio
   *  v-model="model"
   *  :val="2nd" @input="onInput"
   *  ></obg-radio>
   */
  export default {
    name: 'obg-radio',
    props: {
      value: {
        required: true
      },
      val: {
        required: true
      },
      disabled: {
        type: Boolean,
        default: false
      },
      focus: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      model: {
        get () {
          return this.value
        },
        set (value) {
          this.$emit('input', value)
        }
      }
    },
    mounted () {
      this.$parent.$on('click', this.onListItemClick)
    },
    methods: {
      onListItemClick () {
        if (this.$parent.$el.classList.contains('obg-list-item') && !this.disabled) {
          this.$emit('input', this.val)
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
/*
  @import '../../styles/common/colors.variables';
  */
  .obg-radio{
    display: inline-block;
    height: 35px;
    width: 35px;
    vertical-align: middle;
    &.disable {
      user-select: none;
      opacity: 0.4;
      pointer-events: none;
    }
    & > input {
      display: none !important;
    }
    & > input + div {
      position: relative;
      &:before, &:after {
        content:'';
        position:absolute;
        top:0;
        left:0;
        border-radius:50%;
        box-sizing:border-box;
      }
      &:before{
        width:35px;
        height:35px;
        border: 1px solid #ffffff; /* color(white); */
        background: rgba(29,29,29,0.8);
      }
      &:after{
        width: 20px;
        height: 20px;
        top: 8px;
        left: 8px;
        background: #393939;
      }
    }
    & > input:checked + div {
      &:after{
        background: #ffffff; /* color(white); */
      }
    }
    & > input:disabled + div {
      &:after{
        background: #ffffff; /* color(white); */
      }
    }
    &:active > input + div{
      &:before{
        border-color:transparent;
      }
      &:after{
        background: #000000; /* color(black); */
      }
    }
    &.focus > input + div {
      &:before{
        border: 1px solid #0078f0; /* color(primary); */
      }
      &:active{
        &:before{
          border: 1px solid #14385c; /* color(secondary); */
        }
      }
    }
  }




</style>
