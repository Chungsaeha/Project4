<template>
  <label class="obg-radio" :class="{'disabled': disable, 'focus': focus}">
    <input type="radio" v-model="model" :value="val" :disabled="disable" @click="onClick">
    <div></div>
  </label>
</template>

<script>
  export default {
    name: 'obg-radio',
    props: {
      value: {
        required: true
      },
      val: {
        required: true
      },
      disable: Boolean,
      focus: Boolean
    },
    computed: {
      model: {
        get () {
          return this.value
        },
        set (value) {
          this.$emit('input', value)
        }
      }
    },
    methods: {
      onClick () {
        console.log('click')
      }
    },
    mounted () {
      this.$parent.$on('click', () => {
        console.log('parend emit click')
      })
    }
  }
</script>
<style lang="scss" scoped>
  .obg-radio{
    display: inline-block;
    height: 30px;
    width: 30px;
    vertical-align: middle;
    & > input {
      display: none !important;
    }
    & > input + div {
      position: relative;
      &:before, &:after {
        content:'';
        position:absolute;
        top:0;
        left:0;
        border-radius:50%;
        box-sizing:border-box;
      }
      &:before{
        width:30px;
        height:30px;
        border:3px solid transparent;
        background:#ffffff;
      }
      &:after{
        width:15px;
        height:15px;
      }
    }
    & > input:checked + div {
      &:after{
        background: #00D4FF;
      }
    }
    &.focus > input + div {
      &:before{
        border: 4px solid #00D4FF;
      }
    }
  }




</style>
