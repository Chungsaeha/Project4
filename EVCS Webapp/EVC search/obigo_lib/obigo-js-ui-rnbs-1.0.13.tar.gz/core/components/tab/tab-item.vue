<template>
  <a
    class="obg-tab-item"
    :class="[{
      'obg-tab-current': currentIndex === $parent.currentIndex,
      'obg-tab-icon': icon || $slots.icon,
      'disabled': disabled,
      'icon-only': !($slots.default)
    }]"
    @click.stop="onItemClick"
    ref="item"
  >
    <span
      class="obg-tab-icon"
      v-if="icon || $slots.icon">
      <slot name="icon">
        <i v-if="icon" :class="iconClass"></i>
      </slot>
    </span>
    <label class="obg-tab-text"><slot></slot></label>
    <!--div class="divider" :style="{'margin-left': (itemWidth - 1) +'px'}"/-->
  </a>
</template>

<script>
  /**
   * @class tab-item
   * @classdesc components/tab-item
   * @param {boolean} [disabled=false]
   * @param {string} [icon]
   * @param {boolean} [selected]
   * @param {slot} [slot] label
   * @param {slot} [icon] icon
   *
   * @example
   * <obg-tab-item
   *  icon='more'
   *  selected
   * >
   *   tab1
   * </obg-tab-item>
   */
  import { childMixin } from '../../mixins/multi-items'

  export default {
    name: 'obg-tab-item',
    mixins: [childMixin],
    props: {
      icon: String,
      disabled: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      iconClass: function () {
        return 'obg-icon-' + this.icon
      }
    },
    data () {
      return {
        itemWidth: 0
      }
    },
    mounted () {
      this.$on('click', () => {
        this.onItemClick()
      })
      this.itemWidth = this.$el.offsetWidth
    },
    updated () {
      this.$nextTick(() => {
        this.itemWidth = this.$el.offsetWidth
        if (this.$refs.item) this.$refs.item.style.itemWidth = this.itemWidth / 2
      })
    }
  }
</script>

<style lang="scss">
/*
  @import '../../styles/common/colors.variables';
  */
  .obg-tab-item{
    position: relative;
    color: #ffffff; /* color(white); */
    font-size: 20px;
    user-select: none;
    text-decoration:none;
    & > .obg-tab-text {
      display: block;
      text-align: center;
      overflow: hidden;
      height:28px;
      text-overflow: ellipsis;
      white-space: nowrap;
      padding: 0 10px 0 10px;
    }
    &:active{
      .obg-tab-icon{
        -webkit-transform: scale(0.85);
        transform: scale(0.85);
      }
      .obg-tab-text{
        -webkit-transform: scale(0.85);
        transform: scale(0.85);
      }
    }
    &.obg-focus {
      background-color: #ffffff; /* color(white); */
      .obg-tab-icon{
        filter: invert(100%);
      }
      .obg-tab-text{
        color:#000000; /* color(black); */
      }
    }
    &.obg-tab-icon {
      display: flex;
      flex:1;
      flex-basis: 120px;
      width: 140px;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      & > .obg-tab-icon {
        display: flex;
        height: 40px;
        justify-content: center;
        align-items: center;
        & > svg {
          height: 32px;
        }
      }
    }
    &.icon-only{
      & > .obg-tab-text{
        display:none;
      }
      & > .obg-tab-icon{
        height: 78px;
      }
    }
    &:not(.obg-tab-icon){
      & > .obg-tab-text {
        line-height: 78px;
        height: inherit;
      }
    }
    &.disabled{
      opacity: 0.3;
      pointer-events: none;
    }

  }


</style>
