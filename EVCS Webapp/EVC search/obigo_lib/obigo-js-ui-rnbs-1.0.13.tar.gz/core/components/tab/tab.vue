<template>
  <div
    class="obg-tab"
    :class="[{
      'is-animated': animated
    }]"
  >
    <!--div class="divider" /-->
    <div
      class="slide-factor"
      ref="slideFactor"
      v-if="animated"
    ></div>
    <slot></slot>
    <!--div class="divider" /-->
  </div>
</template>

<script>
  /**
   * @class tab
   * @classdesc components/tab
   * @param {slot} [slot] tab-item
   * @param {boolean} [animated=true]
   *
   * @example
   * <obg-tab v-model="btnGroup" :animated=true :value=2>
   *    <obg-tab-item>A</obg-tab-item>
   *    <obg-tab-item selected>B</obg-tab-item>
   *    <obg-tab-item>C</obg-tab-item>
   * </obg-tab>
   */
  import { parentMixin } from '../../mixins/multi-items'
  // import Events from '../../features/events'

  export default {
    name: 'obg-tab',
    mixins: [parentMixin],
    data () {
      return {
        tweeningWidth: 0,
        slidePosition: 0,
        clientWidth: 0
      }
    },
    props: {
      animated: {
        type: Boolean,
        default: true
      }
    },
    watch: {
      currentIndex (val, oldVal) {
        if (this.animated) {
          const slidePosition = this.currentIndex * this.tweeningWidth
          if (typeof oldVal === 'undefined' || oldVal < 0) {
            this.tween(0, slidePosition, this.$slideFactor, 0)
          } else {
            const startValue = oldVal * this.tweeningWidth
            this.tween(startValue, slidePosition, this.$slideFactor, 200)
          }
        }
      }
    },
    mounted () {
      if (this.$children.length < 2 || this.$children.length > 4) {
        throw new Error('Count of tab-item is ' + this.$children.length + '\n Number of tab-item should be 2~4')
      }
      this.clientWidth = this.$el.clientWidth
      this.tweeningWidth = this.$children[1].$el.offsetWidth
      this.$slideFactor = this.$refs.slideFactor
      if (this.$slideFactor) this.$slideFactor.style.width = this.tweeningWidth + 'px'
    },
    updated () {
      this.$nextTick(() => {
        if (this.$children.length > 1 && this.animated) {
          this.tweeningWidth = this.$children[1].$el.offsetWidth
          if (this.$slideFactor) {
            this.$slideFactor.style.width = this.tweeningWidth + 'px'
            this.$slideFactor.style.transform = 'translateX(' + (this.currentIndex * this.tweeningWidth) + 'px)'
          }
        }
      })
    },
    methods: {
      tween: function (startValue, endValue, el, duration) {
        const _style = el.style
        _style.transitionDuration = duration + 'ms'
        _style.webkitTransitionDuration = duration + 'ms'
        _style.transform = 'translateX(' + (endValue) + 'px) translateZ(0px)'
        _style.WebkitTransform = 'translateX(' + (endValue) + 'px) translateZ(0px)'
      }
    }
  }
</script>

<style lang="scss" scoped>
/* 
  @import '../../styles/common/colors.variables';
  */
  .obg-tab{
    position: relative;
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
  }

</style>
