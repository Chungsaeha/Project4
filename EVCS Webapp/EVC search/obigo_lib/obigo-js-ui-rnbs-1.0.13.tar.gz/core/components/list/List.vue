<template>
  <div class='obg-list' >
    <div class='scroll-container' >
      <slot></slot>
      <div class='dummy-item' v-if="hideDummyItem == false" ></div>
    </div>
  </div>
</template>

<script>
import IScroll from '../../features/iscroll'
import spm from './scroll-position-manager'
import listItem from './list-item'
/**
 * @class list
 * @classdesc components/list
 * @param {boolean} [hideDummyItem=false] hide/show last dummy item.
 * @param {number} targetElementIndex
 * @param {number} [targetElementIndex] scroll to targetElement when updated
 * @param {string} [listKey] unique list id in page.<br/>if do not define this property, List component can not save last scroll position.<br/>and be careful do not duplicate with another List in same page.
 * @example
 * <obg-list >
 *  <obg-list-item>item1</obg-list-item>
 *  <obg-list-item>item2</obg-list-item>
 *  <obg-list-item>item3</obg-list-item>
 * </obg-list>
 */
export default {
  name: 'obg-list',
  props: {
    hideDummyItem: {
      type: Boolean,
      default: false
    },
    targetElementIndex: {
      type: Number
    },
    listKey: {
      type: String
    }
  },
  data () {
    return {
    }
  },
  methods: {
    makeScroll: function () {
      if (this.$el.querySelectorAll('.scroll-container > .obg-list-item, .scroll-container > .obg-accordion').length === 0 || this.$slots.default === undefined || this.$slots.default.length === 0) {
        this.isEmpty = true
        return
      }
      this.isEmpty = false
      this.$scroll = new IScroll(this.$el, {
        probeType: 2,
        bounce: true,
        mouseWheel: false,
        scrollbars: true,
        fadeScrollbars: true,
        interactiveScrollbars: false,
        scrollXThreshold: listItem.horiThreshold,
        scrollYThreshold: listItem.vertiThreshold,
        click: true,
        disableMouse: !('onmousedown' in window),
        disablePointer: true,
        disableTouch: !('ontouchstart' in window),
        snap: '.obg-list-item, .obg-accordion',
        deceleration: 0.001,
        dummyItem: !this.hideDummyItem,
        preventDefaultException: {
          // default config, all form elements,
          // extended with a WebComponents Custom Element from the future
          tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT|X-WIDGET)$/,
          // and allow any element that has an accessKey (because we can)
          accessKey: /.+/
        }
      })
      this.$scroll.on('scrollEnd', this.scrollEnd)
      var lastPos = 0
      if (this.$router) { // 팝업의 컴포넌트로 list를 생서할 시 router는 전달되지 않으므로 라우터 검사 후 라우터 사용
        lastPos = spm.get(this.listKey + this.$router.history.current.fullPath)
      }
      if (this.$router && this.$router.isBack === true && lastPos !== undefined) {
        this.$scroll.goToPage(0, lastPos.pageY, 0)    // scrollTo를 사용하면 iscroll의 pages속성을 업데이트하지않아 snap이 적용된 스크롤 동작이 정상적이지 않음.
      } else {
        this.scrollToElement(this.targetElementIndex)
      }
    },
    scrollEnd () {
      if (this.listKey !== undefined && this.$router) {
        spm.set(this.listKey + this.$router.history.current.fullPath, this.$scroll.currentPage)
      }
    },
    refreshScroll: function () {
      console.log('scroll update')
      if (this.$scroll) {
        if (this.$el.querySelectorAll('.scroll-container > .obg-list-item, .scroll-container > .obg-accordion').length === 0 || this.$slots.default === undefined || this.$slots.default.length === 0) {
          this.isEmpty = true
          return
        } else {
          this.isEmpty = false
          this.$scroll.refresh()
        }
      } else {
        this.makeScroll()
      }
    },
    scrollToElement: function (index) {
      if (index !== undefined && this.$slots.default[index]) {
        this.$scroll.scrollToElement(this.$slots.default[index].elm, 0)
      }
    }
  },
  updated: function () {
    let nowScrollHeight = this.$el.firstChild.scrollHeight
    if (this.beforeScrollHeight !== nowScrollHeight) {
      this.refreshScroll()
      this.beforeScrollHeight = nowScrollHeight
    }
    if (this.isEmpty === false) {
      this.scrollToElement(this.targetElementIndex)
    }
  },
  mounted: function () {
    this.makeScroll()
    this.beforeScrollHeight = this.$el.firstChild.scrollHeight
    this.$on('updateScroll', this.refreshScroll)  // accordion에서 list item이 동적으로 변경시 updateScroll 이벤트 발생.
  },
  beforeDestroy: function () {
    if (this.$scroll) {
      this.$scroll.destroy()
      this.$scroll = undefined
    }
  }

}
</script>
<style lang="scss" scoped >
  .obg-list{
    position:relative;
    width:100%;
    overflow:hidden;
    color:white;
    .dummy-item{
      width:100%;
      height:78px;
    }
  }
</style>

