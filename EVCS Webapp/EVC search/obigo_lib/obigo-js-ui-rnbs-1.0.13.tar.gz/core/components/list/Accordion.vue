<template>
    <div class='obg-accordion' >
      <div class='content' @click="handleClick"  @touchstart='down' @touchend='up' @touchcancel='up' ref='content'  >
        <div class='content-area'>
          <slot name='content'  ></slot>
        </div>
        <div class='arrow-area' >
          <div class='icon obg-icon-chevron-right' :class='{open : showChildItems}' >  </div>
        </div>
      </div>
      <transition name='show-children' @after-enter='animationEnter' @after-leave='animationLeave' >
        <div class='inner-item-container' v-if='showChildItems' >
          <slot name='children' ></slot>
        </div>
      </transition>
    </div>
</template>

<script>
/**
 * obg-accordion
 * @class accordion
 * @classdesc components/accordion
 * @param {slot} [slot] content
 * @param {slot} [slot] children
 *
 * @example
 * <obg-accordion>
 *  <div slot='content'> item content </div>
 *  <div slot='children' >
 *    <obg-list-item>item1</obg-list-item>
 *    <obg-list-item>item2</obg-list-item>
 *    <obg-list-item>item2</obg-list-item>
 *  </div>
 * </obg-accordion>
 *
 */
export default {
  name: 'obg-accordion',
  data () {
    return {
      showChildItems: false
    }
  },
  methods: {
    handleClick (e) {
      this.showChildItems = !this.showChildItems
      this.$emit('click', e)
    },
    animationEnter (el) {
      this.$parent.$emit('updateScroll')
    },
    animationLeave (el) {
      this.$parent.$emit('updateScroll')
    },
    down (e) {
      this.$refs.content.classList.add('active')
    },
    up (e) {
      this.$refs.content.classList.remove('active')
    }

  },
  mounted () {
    // check. is it portrait view?
    // accordion component can be used in portrait view.
  }
}
</script>
<style lang="scss" >
.obg-accordion{
    min-height:69px;
    position:relative;
    box-sizing:border-box;

    display:flex;
    flex-direction:column;

    &:nth-child(even){
      background-color:#000000;
    }
    &:nth-child(odd){
      background-color:#191919;
    }
    .content{
      height:69px;
      padding:10px 10px;
      display:flex;
      flex-direction:row;
      width:100%;
      &:active, &.active{
          background-color:#00596b;
          border:2px solid white;
          padding:8px 8px;
      }
      .content-area{
        flex:1;
        display:flex;
        justify-content:flex-start;
        align-items:center;
      }
      .arrow-area{
        display:flex;
        justify-content:center;
        align-items:center;
        > .icon{
          display:flex;
          height:55px;
          width:55px;
          transform:scale(0.5);
          -webkit-transform:scale(0.5);
          transition: transform 0.2s;
          -webkit-transition: transform 0.2s;
          &.open{
            transform:rotate(90deg) scale(0.5);
            -webkit-transform:rotate(90deg) scale(0.5);
          }
        }
      }
    }
    .obg-list-item{
      padding-left:40px;
      &:nth-child(even){
        background-color:#000000;
      }
      &:nth-child(odd){
        background-color:#191919;
      }
      &:active{
        padding-left:38px;
        background-color:#00596b;
      }
    }
    .show-children-enter-active{
      transition:all 0.4s;
    }
    .show-children-leave-active{
      transition:all 0.2s;
    }
    .show-children-enter,
    .show-children-leave-to{
      opacity:0;
    }

}
</style>

