<template>
  <div class="obg-footer">
    <!--div class="obg-footer-mask" v-show=mask></div-->
    <obg-button class="footer-button back" type="footer" icon="back" @click="onClickBack" :disabled="this.disable == 'left' || this.disable =='both' ? true : false"></obg-button>
    <div class="zone-3"><slot></slot></div>
    <obg-context-menu
      class="footer-button context"
      btnType="footer"
      :icon="rightIcon"
      :disabled="this.disable == 'right' || this.disable =='both' ? true : false"
      :options="options"
      @input="onInput"
      @open="onOpen"
      @close="onClose"
      @click="onClickContextMenu"
      :scene="contextMenuScene"
      ref="contextMenu"
    ></obg-context-menu>
  </div>
</template>

<script>
/**
  * obg-footer
  * @class footer
  * @classdesc components/footer
  * @param {string} [disable=none|left|right|both]
  * @param {string} [rightIcon=more]
  * @param {boolean} [mask=false]
  * @param {slot} [slot] zone-3
  * @param {function} [back] onBack cb
  * @event {string} [input]
  *
  * @example
  * <obg-footer :mask=false @back='onBack' :disable='left'>
  *   <obg-button-group v-model="btnGroup" :animated=true >
  *     obg-button-group-item icon='play'> Player </obg-button-group-item>
  *   </obg-button-group>
  * </obg-footer>
 */
import button from '../button'
import contextMenu from '../context-menu'

export default {
  name: 'obg-footer',
  components: {
    'obg-button': button,
    'obg-context-menu': contextMenu
  },
  mounted () {
    const back = this.$children[0]
    const contextMenu = this.$children[this.$children.length - 1]
    const children = this.$children[1].$children

    this.$focus._addComponent(back.$el, {scene: this.scene, order: 1, zone: 3}, back.$vnode)

    if (this.$children.length !== 2) {
      children.forEach((child, index) => {
        this.$focus._addComponent(child.$el, {scene: this.scene, order: index + 2, zone: 3}, child.$vnode)
      })
      this.$focus._addComponent(contextMenu.$el, {scene: this.scene, order: children.length + 2, zone: 3}, contextMenu.$vnode)
    } else {
      this.$focus._addComponent(contextMenu.$el, {scene: this.scene, order: 2, zone: 3}, contextMenu.$vnode)
    }
  },
  beforeDestroy () {
    let count = (this.$children.length === 2) ? 2 : this.$children[1].$children.length + 2
    for (let i = 1; i < count; i++) {
      this.$focus._removeComponent(null, {zone: 3, scene: this.scene, order: i})
    }
  },
  props: {
    mask: {
      type: Boolean,
      default: false
    },
    disable: {
      type: String,
      default: 'none',
      validator (value) {
        return [
          'none',
          'left',
          'right',
          'both'
        ].indexOf(value) > -1
      }
    },
    rightIcon: {
      type: String,
      default: 'spread'
    },
    options: {
      type: Array,
      default: () => []
    },
    scene: {
      default: 0
    },
    contextMenuScene: {
      default: 800
    }
  },
  methods: {
    onClickBack (evt) {
      this.$emit('back', evt)
    },
    onInput (evt) {
      this.$emit('input', evt)
    },
    onOpen () {
      this.$focus.setScene(this.contextMenuScene)
      this.$emit('open')
    },
    onClose () {
      this.$focus.setScene(this.scene)
      this.$emit('close')
    },
    onClickContextMenu () { // click event from focus module
      const $target = this.$refs.contextMenu.$el
      const clickEvent = new MouseEvent('click', {
        'view': window,
        'bubbles': true,
        'cancelable': false
      })
      $target.dispatchEvent(clickEvent)
    }
  }
}
</script>

<style lang="scss">
/* 
  @import '../../styles/common/colors.variables.scss';
*/
  .obg-footer{
    display:flex;
    position: absolute;
    bottom: 0px;
    justify-content: center;
    align-items: center;
    text-align: center;
    .zone-3{
      display: flex;
      align-items: center;
      justify-content: center;
    }
    /*.obg-footer-mask{
      position:absolute;
      width:100%;
      height:78px;
      box-shadow: 0 0 10px 5px rgba(20,20,20,0.3);
      background: linear-gradient(to bottom, rgba(20,20,20,0.3) 0%, rgba(20,20,20,0.34) 8%, rgba(20,20,20,0.38) 16%, rgba(20,20,20,0.42) 24%, rgba(20,20,20,0.46) 32%, rgba(20,20,20,0.50) 40%, rgba(20,20,20,0.54) 48%, rgba(20,20,20,0.58) 56%, rgba(20,20,20,0.62) 64%, rgba(20,20,20,0.66) 72%, rgba(20,20,20,0.7) 80%, rgba(20,20,20,0.74) 90%, rgba(20,20,20,0.78) 100%);
    }*/
    .footer-button{
      float:left;
      z-index: 150;
      /*&:first-of-type{
        margin-right: auto;
        &:before{
          position: absolute;
          top: 19px;
          right: -1px;
          display: block;
          content: '';
          width: 1px;
          height: 37px;
          background: color(grey-3);
        }
      }
      &:last-child{
        margin-left:auto;
        &:before{
          position: absolute;
          top: 19px;
          left: -1px;
          display: block;
          content: '';
          width: 1px;
          height: 37px;
          background: color(grey-3);
        }
      }
      &:disabled{
        opacity: 1;
        & > span{
          opacity:0.5;
        }
      }*/
    }
  }
</style>
