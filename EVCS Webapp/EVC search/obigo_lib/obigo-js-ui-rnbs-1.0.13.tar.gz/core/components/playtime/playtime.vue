<template>
  <div
    class="obg-playtime"
    :style="{ 'width': playtimeWidth + 'px'}"
  >
    <div class="obg-playtime-label start">
      {{minTime}}
    </div>
    <obg-slider
      :min="min"
      :max="max"
      :barHeight="barHeight"
      :sliderWidth="sliderWidth"
      :focus="focus"
      :thumbLabel="false"
      :disabled="disabled"
      v-model="model"
      @input="onInput"
      @mousedown.stop
      @mouseup.stop
    ></obg-slider>
    <div class="obg-playtime-label end">
      {{maxTime}}
    </div>
  </div>
</template>
<script type="text/babel">
  /**
   * @class playtime
   * @classdesc components/playtime
   * @param {number} [min=0]
   * @param {number} [max=100]
   * @param {number} [step=1]
   * @param {number} [value=0]
   * @param {number} [barHeight=5]
   * @param {number} [sliderWidth=500]
   * @param {number} [playtimeWidth=500]
   * @param {boolean} [draggable=true]
   * @param {boolean} [disabled=false]
   *
   * @example
   * <obg-playtime
   *  v-model="model"
   *  :min="0"
   *  :max="100" @input="onInput"
   *  ></obg-playtime>
   */
  import slider from '../slider'
  import Utils from '../../utils'

  export default {
    name: 'obg-playtime',
    components: {
      'obg-slider': slider
    },
    props: {
      min: {
        type: Number,
        default: 0
      },
      max: {
        type: Number,
        default: 100
      },
      disabled: {
        type: Boolean,
        default: false
      },
      value: {
        type: Number,
        default: 0
      },
      barHeight: {
        type: Number
      },
      sliderWidth: {
        type: Number,
        default: 468
      },
      playtimeWidth: {
        type: Number,
        default: 800
      }
    },
    computed: {
      minTime () {
        if (this.value === 0) {
          return Utils.time.secToTime(this.min)
        }
        return Utils.time.secToTime(this.value)
      }
    },
    watch: {
      value (val) {
        this.model = (val < this.max) ? val : this.max
      },
      max (val) {
        this.maxTime = Utils.time.secToTime(val)
      }
    },
    data () {
      return {
        model: (this.value < this.min) ? this.min : this.value,
        focus: false,
        maxTime: Utils.time.secToTime(this.max)
      }
    },
    mounted () {
//      this.$on('jogclick', () => {
//        this.focus = !(this.focus)
//        if (this.focus) {
//            // TODO add jog event listner - value up/down
//        } else {
//            // TODO remove jog event
//        }
//      })
//      this.$on('focusout', () => {
//        this.focus = false
//      })
    },
    methods: {
      onInput (val) {
        this.$emit('input', val)
      }
    }
  }
</script>
<style lang="scss" scoped>
/*
  @import '../../styles/common/colors.variables';
  */
  .obg-playtime {
    position: relative;
    display: flex;
    height: 69px;
    overflow: hidden;
    & > .obg-slider{
      margin: 0 auto;
    }
    & > .obg-playtime-label{
      display: flex;
      position: relative;
      align-items: center;
      color: rgb(161,162,179); /* color(grey-3); */
      font-size: 21px;
      line-height: 120%;
      &.start{
        left: 50px;
      }
      &.end{
        right: 50px;
      }
    }
  }

</style>
