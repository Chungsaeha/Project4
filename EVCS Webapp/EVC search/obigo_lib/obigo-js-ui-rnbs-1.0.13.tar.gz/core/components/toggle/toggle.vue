<template>
  <div
    class="obg-toggles"
    :class="[{
      'is-animated': animated
    }]"
    v-obg-touch-swipe="swipeHandler"
  >
    <div class="slide-factor" v-if="animated" :style="{width: (itemWidth + 2) + 'px'}" ></div>
    <obg-toggle-item
      v-for="(item, index) in items" :disabled="item.disabled"
      :key="index"
      :width = itemWidth
    >
      {{ item | itemLabel }}
    </obg-toggle-item>
  </div>
</template>

<script>
  /**
   * @class toggles
   * @classdesc components/toggles
   * @param {number} [itemWidth=130]
   * @param {array} [items] required
   * @param {boolean} [animated=true]
   * @param {array} [labels]
   * @param {number} value
   *
   * @example
   * <obg-toggles :items="['label1', 'label2', ...]" v-model="value">
   * </obg-toggles>
   */
  import { parentMixin } from '../../mixins/multi-items'
  import toggleItem from './toggle-item.vue'

  export default {
    name: 'obg-toggle',
    mixins: [parentMixin],
    components: {
      'obg-toggle-item': toggleItem
    },
    data () {
      return {
      }
    },
    filters: {
      itemLabel (obj) {
        if (obj.label) {
          return obj.label
        } else {
          return obj
        }
      }
    },
    props: {
      animated: {
        type: Boolean,
        default: true
      },
      itemWidth: {
        type: Number,
        default: 130
      },
      items: {
        type: Array,
        required: true,
        validator (arr) {
          arr.map((item) => {
            let type = typeof item
            if (type === 'object') {
              if (!item.label) return false
            } else if (type !== 'string') {
              return false
            }
          })
          return true
        }
      }
    },
    watch: {
      currentIndex (val, oldVal) {
        if (this.animated) {
          const slidePosition = val * this.tweeningWidth
          if (typeof oldVal === 'undefined' || oldVal < 0) {
            this.tween(0, slidePosition, this.$slideFactor, 0)
          } else {
            const startValue = oldVal * this.tweeningWidth
            this.tween(startValue, slidePosition, this.$slideFactor, 200)
          }
        }
      }
    },
    mounted () {
      this.clientWidth = this.$el.clientWidth
      this.tweeningWidth = this.clientWidth / this.number
      this.$slideFactor = this.$el.children[0]
      if (this.$children.length < 2 || this.$children.length > 5) {
        throw new Error('Count of toggles ' + this.items.length + '\n Number of item should be 2~5')
      }
      this.$parent.$on('click', this.onListItemClick)
    },
    methods: {
      tween: function (startValue, endValue, el, duration) {
        const _style = el.style
        _style.transitionDuration = duration + 'ms'
        _style.webkitTransitionDuration = duration + 'ms'
        _style.transform = 'translateX(' + (endValue) + 'px) translateZ(0px)'
        _style.WebkitTransform = 'translateX(' + (endValue) + 'px) translateZ(0px)'
      },
      swipeHandler (obj) {
        let children = this.$children.slice()
        let index = this.currentIndex
        let targetIndex = 0
        let candidateArr
        if (obj.direction === 'left') {
          if (index === 0) return
          candidateArr = children.slice(0, index).reverse()
          targetIndex = this.checkAvailable(candidateArr)
          if (targetIndex < 0) return
          this.currentIndex = index - (targetIndex + 1)
        } else {
          if (index >= children.length - 1) return
          candidateArr = children.slice(index + 1)
          targetIndex = this.checkAvailable(candidateArr)
          if (targetIndex < 0) return
          this.currentIndex = index + targetIndex + 1
        }
      },
      checkAvailable (arr) {
        return arr.findIndex(item => {
          return !item.$el.classList.contains('disabled')
        })
      },
      onListItemClick () {
        if (this.disabled) return
        if (this.$parent.$el.classList.contains('obg-list-item')) {
          let children = this.$children.slice()
          let index = this.currentIndex
          let candidateArr = children.slice(index + 1)
          let targetIndex = this.checkAvailable(candidateArr)
          this.$emit('input', (targetIndex < 0) ? 0 : index + targetIndex + 1)
        }
      }
    }
  }
</script>

<style lang="scss">
  .obg-toggles{
    display: flex;
    background-color: #1a1a1a;
    border-radius: 40px;
    border: 1px solid #fff;
    position: relative;
    & > a{
      text-decoration:none;
    }
    &.is-animated > a.obg-toggles-current{
      border:2px solid transparent;
      background:none;
      &:active{
        border: 1px solid #fff;
        background: #00596b;
      }
    }
    & > .slide-factor{
      position: absolute;
      width: 147px;
      height: 45px;
      border: 1px solid #fff;
      background-color: #fff;
      border-radius: 30px;
      left:-1px;
      &:active{
        background: #00596b;
        color:#fff;
      }
    }
  }

</style>
