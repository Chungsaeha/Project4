<template>
  <button
    class="obg-toggle-item"
    :class="[{
      'obg-toggle-current': currentIndex === $parent.currentIndex,
      'disabled': disabled
    }]"
    @click.stop="onItemClick"
    @touchstart="onPressItem" @touchend="onReleaseItem"
    :style="{width: width + 'px'}"
  >
    <label class="obg-toggle-text"><slot></slot></label>
  </button>
</template>
<script>
/**
 * @class toggle-item
 * @classdesc components/toggle-item
 * @param {number} [width]
 * @param {boolean} [disabled=false]
 * @param {boolean} [selected]
 * @param {slot} [slot] label
 *
 * @example
 * <obg-toggle-item @click ='onClick' selected>
 *   label1
 * </obg-toggle-item>
 */
import { childMixin } from '../../mixins/multi-items'

export default {
  name: 'obg-toggle-item',
  mixins: [childMixin],
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    width: {
      type: Number
    }
  },
  methods: {
    onPressItem (e) {
      e.currentTarget.classList.add('active')
    },
    onReleaseItem (e) {
      e.currentTarget.classList.remove('active')
    }
  }
}
</script>

<style lang="scss">
/*
  @import '../../styles/common/colors.variables';
  */
  .obg-toggle-item{
    position: relative;
    display: flex;
    width: 145px;
    height: 45px;
    border-radius: 40px;
    color: #ffffff; /* color(white); */
    background:none;
    border: 1px solid transparent;
    font-size: 32px;
    outline: none;
    user-select: none;
    align-items: center;
    justify-content: center;
    &.obg-focus {
      box-shadow: inset 0 0 0 4px #fff;
    }
    & > .obg-toggle-text{
      display:block;
      text-align: center;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      padding: 0 10px 0 10px;
      line-height: 24px;
      margin: 0 auto;
    }

    &:active, &.active{
      border:1px solid #ffffff; /* color(white); */
      background: #14385c; /* color(secondary); */
    }
    &.obg-focus{
      color:#ffffff; /* color(white); */
      box-shadow:none;
      border:4px solid #ffffff; /* color(white); */
    }
    &.obg-toggle-current{
      color: #1a1a1a;
      &:active, &.active{
        background: #00596b;
        color:#fff;
      }
    }
    &.disabled{
      opacity:0.3;
      pointer-events: none;
    }
  }
</style>
