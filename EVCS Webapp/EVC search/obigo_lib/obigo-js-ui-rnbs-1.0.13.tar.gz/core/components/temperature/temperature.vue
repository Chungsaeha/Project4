<template>
  <div class="obg-temperature">
    {{temperature}}{{mark}}
  </div>
</template>

<script>
export default{
  name: 'obg-temperature',
  props: {
    isFahrenheit: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      temperature: '27',
      mark: this.isFahrenheit ? '℉' : '℃'
    }
  }
}
</script>
<style lang="scss" >
  .obg-temperature{
    font-size: 37px;
    display: block;
    width: 138px;
    height: 39px;
  }
</style>
