<template>
  <obg-button :icon="icon" ref="origin" :type="btnType" class="anchor">
    <slot name="icon"></slot>
    <obg-popover
      ref="popover"
      anchor="top middle"
      self="bottom right"
      class="context-menu"
      :style="{ height: contextMenuHeight + 'px' }"
      @open="showDimScreen"
      @close="hideDimScreen"
    >
      <div
        :class="['menu-item',
          { 'disabled': item.disabled }
        ]"
        v-for="(item, index) in options"
        :name="item.name"
        @click.stop="onItemClick"
        v-obg-focus="{scene: scene, order: index + 1}"
        :key="index"
      >
        <span class="item-content">
          {{item.label}}
        </span>
      </div>
    </obg-popover>
    <div ref="dim" class="dim-context-menu"></div>
    <button ref="closeButton" class="close-button-context-menu animate-scale" v-obg-focus="{scene: scene, order: (options.length === 0) ? -1 : options.length + 1}">
      <i class="obg-icon-close" />
    </button>
  </obg-button>
</template>

<script>
  /**
   * @class context-menu
   * @classdesc components/context-menu
   * @param {boolean} [disable]
   * @param {slot} [slot]
   * @param {string} [btnType=round]
   * @param {string} [icon=more]
   * @param {number} [focusZone=99]
   * @param {array} options required
   * @param [scene=800]
   * @example
   * <obg-context-menu
   *  icon="more"
   *  :options="[{name: 'opt1', label: 'Option'}, {name: 'opt2', label: 'Advanced Setting'}, {name: 'opt3', label: 'Reset'}, {name: 'opt4', label: 'Help'}, {name: 'opt5', label: 'Smart Tutoriels'}]"
   * >
   * </obg-context-menu>
   */
  import popover from '../popover'
  import button from '../button'
  import Events from '../../features/events'
  export default {
    props: {
      disable: Boolean,
      btnType: {
        type: String,
        default: 'round'
      },
      icon: {
        type: String,
        default: 'more'
      },
      focusZone: {
        type: Number,
        default: 99
      },
      scene: {
        default: 800
      },
      options: {
        type: Array,
        required: true,
        default: [],
        validator (arr) {
          if (arr.length < 0 || arr.length > 5) {
            return false
          }
          arr.forEach((item) => {
            if (!(item.hasOwnProperty('name') && item.hasOwnProperty('label'))) {
              throw new Error('options should be [{ name: xxxx, label: yyyy}, ...]')
            }
          })
          return true
        }
      }
    },
    components: {
      'obg-button': button,
      'obg-popover': popover
    },
    computed: {
      contextMenuHeight () {
        return this.options.length * 68 + this.options.length - 3
      }
    },
    methods: {
      close () {
        if (this.$refs.popover) this.$refs.popover.close()
        this.hideDimScreen()
      },
      __open (event) {
        if (!this.disable) {
          this.$refs.popover.open(event)
        }
      },
      onItemClick (e) {
        let name = e.currentTarget.getAttribute('name')
        this.$emit('input', name)
        this.close()
      },
      showDimScreen () {
        document.body.appendChild(this.$dim)
        document.body.appendChild(this.$closeButton)
        this.$dim.addEventListener('click', this.close)
        this.$closeButton.addEventListener('click', this.close)
        this.$emit('open')

        this.$nextTick(() => {
          setTimeout(() => {
            Events.$emit('popup:show', {
              type: 'context',
              el: document.getElementsByClassName('obg-popover context-menu')[0]
            })
          }, 200)
        })
      },
      hideDimScreen () {
        this.$dim.removeEventListener('click', this.close)
        this.$closeButton.removeEventListener('click', this.close)
        this.$emit('close')
        if (document.body.querySelector('.dim-context-menu')) {
          document.body.removeChild(this.$dim)
          document.body.removeChild(this.$closeButton)
        }
        Events.$emit('popup:hide', {
          type: 'context'
        })
      }
    },
    mounted () {
      const originPos = this.$refs.origin.$el.getBoundingClientRect()

      this.target = this.$refs.popover.$el.parentNode
      this.target.addEventListener('contextmenu', this.__open)
      this.$dim = this.$refs.dim
      this.$closeButton = this.$refs.closeButton
      this.$closeButton.style.top = (originPos.top + originPos.height / 2 - this.$refs.closeButton.offsetHeight / 2) + 'px'
      this.$closeButton.style.left = (originPos.left + originPos.width / 2 - this.$refs.closeButton.offsetWidth / 2) + 'px'

      let $origin = this.$refs.origin.$el.getElementsByClassName('obg-button-text')[0]
      $origin.style.display = 'none'

      this.$nextTick(() => {
        this.$el.childNodes[2].removeChild(this.$dim)
        this.$el.childNodes[2].removeChild(this.$closeButton)
      })
    },
    beforeDestroy () {
      this.target.removeEventListener('contexmenu', this.handler)
    }
  }
</script>
<style lang="scss" scoped>
/*
  @import '../../styles/common/colors.variables';
  */
  div.context-menu{
    width: 355px;
    height: 343px;
    border: 1px solid rgb(161,162,179); /* color(grey-3); */
    overflow-y: hidden !important;
    margin-top: 36px;
    > div.menu-item {
      height:68px;
      color:#ffffff; /* color(white); */
      font-size:32px;
      text-indent:15px;
      display: flex;
      align-items: center;
      background: #000000; /* color(black); */
      border-bottom: 1px solid #3a3c3d;
      border-right: 15px solid #030303;
      border-left: 15px solid #030303;
      &:last-child{
        border-bottom: 1px solid #030303;
      }
      &:active{
        background: #14385c; /* color(secondary); */
        border-right: 15px solid #14385c; /* color(secondary); */
        border-left: 15px solid #14385c; /* color(secondary); */
      }
      &.disabled{
        color: #555;
        pointer-events: none;
      }
      &.obg-focus{
        &:before{
          position: absolute;
          height: 60px;
          width: 345px;
          content: '';
          border: 4px solid #fff;
          margin-top: 0px;
          margin-left: -15px;
        }
        &:after{
          border-color:#ffffff; /* color(white) */
        }
      }
    }
  }
  .dim-context-menu{
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0px;
    left: 0px;
    z-index: 160;
    background: rgba(0, 0, 0, 0.7);
  }
  .close-button-context-menu{
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #222226; /* color(dark); */
    height: 69px;
    width: 69px;
    border-radius: 35px;
    z-index: 300;
    &:active{
      background: #14385c; /* color(secondary); */
    }
    & > i {
      margin-left: 10px;
      margin-right: 10px;
    }
    &.obg-focus{
      box-shadow: inset 0 0 0 4px #fff;
    }
  }
  .animate-scale {
    animation: popover-scale .2s;
  }

  @keyframes popover-scale {
    0% {
      opacity: 0;
      transform: scale(0.7)
    }
    100% {
      opacity: 1;
      transform: scale(1)
    }
  }
</style>
