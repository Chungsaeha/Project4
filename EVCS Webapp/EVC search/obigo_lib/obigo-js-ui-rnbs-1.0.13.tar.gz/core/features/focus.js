import appManager from './appManager'
import {hardkeyCode, hardkeyInstance as hardkey} from './hardkey'
import Events from '../features/events'

class Focus {
  /**
   * @constructor
   */
  constructor () {
    this.appManager = appManager
    this._focusMap = new Map()

    this._currentScene = 0
    this._currentZone = 2 // only 2 or 3
    this._currentOrder = 0

    this._zoneFocusMode = false
    this._componentFocusMode = false
    this._componentControlMode = false

    this._hardkeyCode = 1000
    this._hardkeyMode = 0
    this._appType = 'widget'

    this._popupType = 'none'
    this._popupZoneStyle = {}
    this._$focusZoneEle = document.createElement('div')

    this._onBodyClickListener = this._onBodyClickListener.bind(this)
    this.prevZone = this.prevZone.bind(this)
    this.nextZone = this.nextZone.bind(this)
    this._onRotaryLeftRight = this._onRotaryLeftRight.bind(this)
    this._handleRotateClick = this._handleRotateClick.bind(this)
    this.exitFocusMode = this.exitFocusMode.bind(this)
    this._handleRotate = this._handleRotate.bind(this)
    this._handleWheelEvent = this._handleWheelEvent.bind(this)
  }

  /**
   * @method _bind
   * @desc bind hardkey/event-bus event
   * @private
   */
  _bind () {
    // hardkey event listener
    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_UP, this.prevZone)
    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_DOWN, this.nextZone)

    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_LEFT, this._onRotaryLeftRight)
    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_RIGHT, this._onRotaryLeftRight)

    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ENTER, this._handleRotateClick)

    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_BUTTON_HOME, this.exitFocusMode)
    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_BUTTON_BACK, this.exitFocusMode)

    if (this.appManager) {
      hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleRotate)
      this._appType = (this.appManager.type === 2) ? 'gadget' : 'widget'
    } else {
      hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleWheelEvent)
    }

    // event bus listener
    Events.$on('scene:update', (scene) => {
      this.setScene(scene)
    })

    // popup event listener
    Events.$on('popup:show', (obj) => {
      console.log('popup-shown')
      if (!obj.el) return
      const popupRect = obj.el.getBoundingClientRect()
      this._popupType = obj.type
      this._popupZoneStyle = {
        'height': popupRect.height,
        'width': popupRect.width,
        'left': popupRect.left,
        'top': popupRect.top
      }
    })
    Events.$on('popup:hide', (obj) => {
      this._popupType = 'none'
      this._popupZoneStyle = {}
    })

    Events.$on('focus:control-get', (obj) => {
      this._unbindRotateListener()
      this._componentControlMode = true
    })
    Events.$on('focus:control-loss', (obj) => {
      this._bindRotateListener()
      this._componentControlMode = false
    })
  }

  _bindRotateListener () {
    if (this.appManager) {
      hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleRotate)
    } else {
      hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleWheelEvent)
    }
    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ENTER, this._handleRotateClick)
  }

  _unbindRotateListener () {
    if (this.appManager) {
      hardkey.removeHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleRotate)
    } else {
      hardkey.removeHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleWheelEvent)
    }
    hardkey.removeHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ENTER, this._handleRotateClick)
  }

  /**
   * @method _handleRotate
   * @param code keycode
   * @param mode keytype
   * @param tick remaintick
   * @desc event handler - csw:rotate
   * @private
   */
  _handleRotate ({code, mode, tick}) { // TODO popup의 경우 존3안갈것, if/else 줄이기
    // store key codes for send remainTick
    this.hardkeyCode = code
    this.hardkeyMode = mode

    if (tick === 0) {
      this.exitFocusMode()
      this._sendRemainTick(0)
      return
    }

    // start zone-focus-mode
    if (!this._zoneFocusMode) {
      this._zoneFocusMode = true
      this._setZoneFocusOn()
      this._sendRemainTick(1)

      window.addEventListener('click', this._onBodyClickListener)

      return
    }

    // zone focus mode
    if (!this._componentFocusMode) {
      if (this._appType === 'gadget') {
        this.exitFocusMode()
        this._sendRemainTick(1)
        return
      }

      if (mode === hardkeyCode.mode.HARDKEY_MODE_RIGHT) {
        this.nextZone()
      } else {
        this.prevZone()
      }
      return
    }

    // component focus mode
    if (mode === hardkeyCode.mode.HARDKEY_MODE_RIGHT) {
      this.nextOrder(tick)
      return
    } else {
      this.prevOrder(tick)
      return
    }
  }

  /**
   * @method _handleWheelEvent
   * @desc event handler for pc environment
   * @private
   */
  _handleWheelEvent () { // for pc environment
    if (this._zoneFocusMode) {
      if (this._componentFocusMode) {
        this.nextOrder()
        // this.prevOrder()
      } else {
        this.nextZone({})
      }
    } else {
      this._zoneFocusMode = true
      window.addEventListener('click', this._onBodyClickListener)
      this._setZoneFocusOn()
    }
  }

  /**
   * @method _handleRotateClick
   * @param code keycode
   * @param mode keytype
   * @desc event handler - csw:click
   * @private
   */
  _handleRotateClick ({code = 1000, mode = 0}) {
    // store key codes for send remainTick
    this._hardkeyCode = code
    this._hardkeyMode = mode

    if (this._zoneFocusMode) {
      if (!this._componentFocusMode) {
        // start component focus mode
        this._currentOrder = this._getClosestFocusableComponent() // find closest focusable component
        if (this._currentOrder === -1) {
          this.exitFocusMode()
          this._sendRemainTick(1)
        } else {
          this._componentFocusMode = true
          this._setZoneFocusOff()
          this._setComponentFocusOn()
          this._sendRemainTick(0)
        }
      } else {
        // component click
        const target = this._getCurrentTarget()
        if (target) {
          const $target = target.el

          if (target.vnode.componentInstance) { // emit event for vue-component
            target.vnode.componentInstance.$emit('click', {
              'view': window,
              'bubbles': true,
              'cancelable': false,
              'currentTarget': $target
            })
            target.vnode.componentInstance.$emit('jog-click', {}) // emit event for slider
          } else { // create click event for html element
            const clickEvent = new MouseEvent('click', {
              'view': window,
              'bubbles': true,
              'cancelable': false,
              'currentTarget': $target
            })
            $target.dispatchEvent(clickEvent)
            const jogClickEvent = new CustomEvent('jog-click', {
              'detail': {}
            })
            $target.dispatchEvent(jogClickEvent)
          }
        }
        this._sendRemainTick(0)
      }
    }
  }

  /**
   * @method _onBodyClickListener
   * @desc exit focus mode when click screen
   * @private
   */
  _onBodyClickListener () {
    this.exitFocusMode()
    this._sendRemainTick(1)
  }

  /**
   * @method _onRotaryLeftRight
   * @param code
   * @param mode
   * @desc exit focus mode when click csw:left or csw:right
   * @private
   */
  _onRotaryLeftRight ({code = 1000, mode = 0}) {
    this._hardkeyCode = code
    this._hardkeyMode = mode
    this.exitFocusMode()
    this._sendRemainTick(1)
  }

  /**
   * @method exitFocusMode
   * @desc exit focus mode
   */
  exitFocusMode () {
    this._setZoneFocusOff()
    this._setComponentFocusOff()
    this._zoneFocusMode = false
    this._componentControlMode = false
    this._componentFocusMode = false
    this._currentZone = 2
    this._currentOrder = 0
    window.removeEventListener('click', this._onBodyClickListener)
    console.log('[obigo-ui] exit focus mode')
  }

  /**
   * @method _setZoneFocusOn
   * @param zone
   * @desc create and add focus-zone element and set style and class
   */
  _setZoneFocusOn (zone = 2) {
    const zoneClass = (zone === 2) ? 'two' : 'three'

    this._$focusZoneEle = document.createElement('div')
    this._$focusZoneEle.classList.add('zone-focus', zoneClass, this._appType, this._popupType)

    if (this._popupType !== 'none') {
      this._$focusZoneEle.style.height = this._popupZoneStyle.height + 'px'
      this._$focusZoneEle.style.width = this._popupZoneStyle.width + 'px'
      this._$focusZoneEle.style.top = this._popupZoneStyle.top + 'px'
      this._$focusZoneEle.style.left = this._popupZoneStyle.left + 'px'
    }

    document.body.appendChild(this._$focusZoneEle)

    Events.$emit('focus:zone-focus-in')
  }

  /**
   * @method _setZoneFocusOff
   * @desc remove zone-focus element from body
   */
  _setZoneFocusOff () {
    if (document.body.getElementsByClassName('zone-focus').length === 0) {
      window.removeEventListener('click', this._onBodyClickListener)
      return
    }
    document.body.removeChild(this._$focusZoneEle)
  }

  /**
   * @method nextZone
   * @desc move to next zone area
   */
  nextZone () {
    this._setComponentFocusOff()
    this._currentOrder = 0

    if (this._currentZone === 2 && this._popupType === 'none' && this._appType !== 'gadget') {
      this._$focusZoneEle.classList.remove('two')
      this._$focusZoneEle.classList.add('three')
      this._currentZone += 1
      if (this._componentFocusMode) {
        this._componentFocusMode = false
        this._setZoneFocusOn(this._currentZone)
      }
      this._sendRemainTick(0)
    } else {
      this.exitFocusMode()
      this._sendRemainTick(1)
    }
  }

  /**
   * @method prevZone
   * @desc move focus to previous zone area
   */
  prevZone () {
    this._setComponentFocusOff()
    this._currentOrder = 0

    if (this._currentZone === 3 && this._popupType === 'none' && this._appType !== 'gadget') {
      this._$focusZoneEle.classList.remove('three')
      this._$focusZoneEle.classList.add('two')
      this._currentZone -= 1
      if (this._componentFocusMode) {
        this._componentFocusMode = false
        this._setZoneFocusOn(this._currentZone)
      }
      this._sendRemainTick(0)
    } else {
      this.exitFocusMode()
      this._sendRemainTick(1)
    }
  }

  /**
   * @method nextOrder
   * @param tick
   * @desc move focus to next focusable component
   */
  nextOrder (tick = 0) {
    this._setComponentFocusOff()
    this._currentOrder = this._getClosestFocusableComponent(this._currentOrder + 1) // find closest focusable component
    this._setComponentFocusOn()
    this._sendRemainTick(0)
  }

  /**
   * @method prevOrder
   * @desc move focus to previous focusable component
   * @param tick
   */
  prevOrder (tick = 0) {
    this._setComponentFocusOff()
    this._currentOrder = this._getClosestFocusableComponent(this._currentOrder - 1, false) // find closest focusable component
    this._setComponentFocusOn()
    this._sendRemainTick(0)
  }

  /**
   * @method _getClosestFocusableComponent
   * @param order
   * @param isNext search direction
   * @return {*}
   * @desc get cloosest focusable component from order(first argument) in current scene
   */
  _getClosestFocusableComponent (order = this._currentOrder, isNext = true) {
    let sceneMap = this._getCurrentSceneMap()
    let scene = this._currentScene
    let n = 0

    if (!sceneMap && this._currentZone === 3) { // footer가 app.vue에 하나 존재하고 페이지에 존재하지 않는 경우 scene을 0으로 하여 footer의 focusable component를 검색
      scene = 0
      sceneMap = this._getSceneMap(this._currentZone, scene)
    }

    const incrementer = (isNext) ? 1 : -1 // prev검색 or next 검색
    const size = (sceneMap) ? sceneMap.size : 0

    order = (order < 0) ? size : (order > size) ? 0 : order // size 넘어서는 경우 보정

    while (n++ < size) {
      if (this._isTargetAvailable(scene, order)) {
        return order
      }
      order = order + incrementer
      order = (order < 0) ? size : (order > size) ? 0 : order
    }

    return -1
  }

  /**
   * @method _isTargetAvailable
   * @param scene
   * @param order
   * @return {boolean}
   * @desc check target able/disable
   */
  _isTargetAvailable (scene, order) {
    const sceneMap = this._getSceneMap(this._currentZone, scene)
    const targetComponent = (sceneMap) ? sceneMap.get(order) : null

    if (targetComponent) {
      let $target = targetComponent.el
      if (!($target.disabled || $target.classList.contains('disabled') || $target.classList.contains('disable'))) return true
    }

    return false
  }

  /**
   * @method _getCurrentTarget
   * @return {null}
   * @desc get current focused component from focus map
   * @private
   */
  _getCurrentTarget () {
    let sceneMap = this._getCurrentSceneMap()

    if (sceneMap && sceneMap.size > 0) {
      return sceneMap.get(this._currentOrder)
    }

    if (this._currentZone === 3) { // zone 3이면서 해당 scene에 별도의 footer가 없는 경우
      sceneMap = this._getSceneMap(this._currentZone, 0)
      return sceneMap.get(this._currentOrder)
    }

    return null
  }

  /**
   * @method _setComponentFocusOn
   * @private
   * @desc add focus class to current focusable component and emit 'focusin' event
   */
  _setComponentFocusOn () {
    let target = this._getCurrentTarget()
    if (target) {
      target.el.classList.add('obg-focus')
      if (target.vnode.componentInstance) {
        target.vnode.componentInstance.$emit('focusin', {'target': target.el})
      }
    }
  }

  /**
   * @method _setComponentFocusOff
   * @private
   * @desc remove focus class to current focusable component and emit 'focusout' event
   */
  _setComponentFocusOff () {
    let target = this._getCurrentTarget()
    if (target) {
      target.el.classList.remove('obg-focus')
      if (target.vnode.componentInstance) {
        target.vnode.componentInstance.$emit('focusout', {'target': target.el})
      }
    }
  }

  /**
   * @method _getZoneMap
   * @param zone
   * @return {V}
   * @private
   * @desc returns the map that specified zone
   */
  _getZoneMap (zone) {
    let zoneMap = this._focusMap.get(zone)
    if (!zoneMap) {
      zoneMap = new Map()
      this._focusMap.set(zone, zoneMap)
    }
    return zoneMap
  }

  /**
   * @method _getSceneMap
   * @param zone
   * @param scene
   * @private
   * @desc returns the map that specified zone and scene
   */
  _getSceneMap (zone, scene) {
    let zoneMap = this._getZoneMap(zone)
    let sceneMap = zoneMap.get(scene)
    if (!sceneMap) {
      sceneMap = new Map()
      zoneMap.set(scene, sceneMap)
    }
    return sceneMap
  }

  /**
   * @method _getCurrentSceneMap
   * @private
   * @desc returns the map that current zone and scene
   */
  _getCurrentSceneMap () {
    const zoneMap = this._focusMap.get(this._currentZone)
    return (zoneMap) ? zoneMap.get(this._currentScene) : null
  }

  /**
   * @method _addComponent
   * @param el
   * @param {number} [scene=0]
   * @param {number} [zone=2]
   * @param {number} [order]
   * @param {object} [vnode]
   * @private
   * @desc add component to focus map when mounted
   * if scene,zone and order is duplicated skip it
   */
  _addComponent (el, {scene = 0, zone = 2, order}, vnode) {
    const sceneMap = this._getSceneMap(zone, scene)
    if (typeof order === 'undefined') { // directive에서 order를 지정하지 않은 경우 순차적으로 order 부여 - keep-alive가 아닌 경우
      order = sceneMap.size
    }
    if (sceneMap.get(order)) {
      console.log('[ObigoUI:error] Focus order is duplicated [ scene : ' + scene + ' / order : ' + order + '] - skip')
      return
    } else {
      sceneMap.set(order, {el: el, vnode: vnode})
    }
  }

  /**
   * @method _removeComponent
   * @param el
   * @param zone
   * @param scene
   * @param order
   * @private
   * @desc remove component from focus map
   */
  _removeComponent (el, {zone = 2, scene = 0, order}) {
    const sceneMap = this._getSceneMap(zone, scene)
    if (typeof order === 'undefined') { // directive에서 order를 지정하지 않은 경우 뒤에서부터 순차적으로 삭제
      order = sceneMap.size - 1
    }
    sceneMap.delete(order)
    this._currentOrder = 0
    this._currentZone = 2
  }

  _sendRemainTick (tick) {
    console.log('notProcessedCount : ' + tick)
    window.hardkeyEventObj.notProcessedCount(this._hardkeyCode, this._hardkeyMode, tick)
  }

  /**
   * @method setScene
   * @param scene
   * @desc set scene
   */
  setScene (scene) {
    this._setZoneFocusOff()
    this._setComponentFocusOff()
    this._zoneFocusMode = false
    this._componentFocusMode = false
    this._currentZone = 2
    this._currentOrder = 0
    this._currentScene = scene
  }

  /**
   * @method storeLastFocusInfo
   * @param scene
   */
  storeLastFocusInfo (scene) {
    // TODO store last focus
  }

  /**
   * @method setFocusPosition
   * @param scene
   * @param order
   * @param zone
   */
  setFocusPosition ({scene = 0, order = 0, zone = 2}) {
    this._setZoneFocusOff()
    this._setComponentFocusOff()
    this._zoneFocusMode = false
    this._componentFocusMode = false
    this._currentOrder = order
    this._currentZone = zone
    this._currentScene = scene
  }

  /**
   * @method getCurrentPosition
   * @return {{order: (*|number), zone: (number|*), scene: (*|number)}}
   */
  getCurrentPosition () {
    return {
      'order': this._currentOrder,
      'zone': this._currentZone,
      'scene': this._currentScene
    }
  }
}

export var focusInstance = new Focus()

export function install (_Vue) {
  focusInstance._bind()
  _Vue.prototype.$focus = focusInstance
  return focusInstance
}
