/**
 * @module util
 * @desc utility functions.
 * @example 
 * var appFrm = window.applicationFramework
 * var util = appFrm.util
 */

class util{

  /**
   * @function getOSVersion 
   * @summary return OS version
   * @return {string} - OS version
   *
   */
  getOSVersion () {
  }

  /**
   * @function getLoggingLevel
   * @summary return logging level
   * @retrun {integer} - logging level
   *
   */
  getLoggingLevel () {
  }
}

