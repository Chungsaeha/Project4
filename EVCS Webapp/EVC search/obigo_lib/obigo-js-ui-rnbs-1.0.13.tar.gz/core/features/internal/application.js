/**
 * @module application
 * @desc application object has information and status of running web application.<br/>
 * this object can control app status and communicate with Obigo AF by events.
 * @example
 * var appManager = window.applicationFramework.applicationManager
 * var application = appManager.getOwnerApplication(window.document)
 */

class application{



  /**
   *
   * @event ApplicationDestroyRequest
   * @summary when application is request destroy by external behavior
   * @example
   * application.addEventListener('ApplicationDestroyRequest', () => {
   *   // todo
   * })
   *
   */


  /**
   * @event ApplicatinNotTopmost
   * @summary when application not shown in top layer
   * @example
   * application.addEventListener('ApplicatinNotTopmost', () => {
   *   // todo
   * })
   *
   */

  /**
   *
   * @event ApplicatinTopmost
   * @summary when application shown in top layer
   * @example
   * application.addEventListener('ApplicatinTopmost', () => {
   *   // todo
   * })
   *
   */

  /**
   *
   * @event ApplicatinNotPrimaryReceiver
   * @summary when application is removed in top of active application list
   * @example
   * application.addEventListener('ApplicatinNotPrimaryReceiver', () => {
   *   // todo
   * })
   *
   */

  /**
   * @event ApplicatinPrimaryReceiver
   * @summary when application is located in top of active application list
   * @example
   * application.addEventListener('ApplicationPrimaryReceiver', () => {
   *   // todo
   * })
   *
   */

  /**
   * @event ApplicationActivated
   * @summary when application has focus
   * @example
   * application.addEventListener('ApplicationActivated', () => {
   *   // todo
   * })
   *
   */

  /**
   *
   * @event AplicationHidden
   * @summary when application hidden to screen
   * @example
   * application.addEventListener('ApplicationHidden', () => {
   *   // todo
   * })
   */

  /**
   *
   * @event AplicationShown
   * @summary when application shown to screen
   * @example
   * application.addEventListener('ApplicationShown', () => {
   *   // todo
   * });
   */

  /**
   *
   * @event ApplicationDeactivated
   * @summary when application lose focus
   * @example
   * application.addEventListener('ApplicationDeactivated', () => {
   *   // todo
   * })
   *
   */

  /**
   *
   * @event ApplicationMessage
   * @summary register message listener to receive message from postMessage function
   * @param {string} message  - receive message
   * @param {string} origin   - target origin
   * @param {string} source   - message source
   * @example
   * application.addEventListener('ApplicationMessage', (message, origin, source) => {
   *   // todo
   * })
   *
   */

  /**
   *
   * @event AmbientColorChanged
   * @summary listen to the change of ambient colors
   * @param {string} color - changed color
   * @example
   * application.addEventListener('AmbientColorChanged', (color) => {
   *   // todo
   * })
   *
   */

  /**
   *
   * @event LanguageChanged
   * @summary listen to the change of current language
   * @param {string} lang - changed language
   * @example
   * application.addEventListener('LanguageChanged', (lang) => {
   *   // todo
   * })
   *
   */

  /**
   *
   * @event PopupButtonReleased
   * @summary listen to the user action of native popup
   * @param {integer} buttonIdx - pressed button index
   * @example
   * application.addEventListener('PopupButtonReleased', (idx) => {
   *   // todo
   * })
   *
   */


  /**
   * @function addEventListener
   * @summary add event to application.<br/>
   *
   * @param {string} evt          - event name
   * @param {function} callback   - callback function
   * @example
   * application.addEventListener('EventName', () => {
   *   // todo
   * })
   *
   */
  addEventListener (evt, callback) {
  }

  /**
   * @function removeEventListener
   * @summary remove event to application
   * @param {string} evt          - event name
   * @param {function} callback   - callback function
   * @example
   * application.removeEventListener('EventName', eventHandler)
   *
   */
  removeEventListener (evt, callback) {
  }

  /**
   * @function home
   * @summary go to native home
   * @example
   * application.home()
   *
   */
  home () {
  }

  /**
   * @function main
   * @summary go to web launcher main
   * @example
   * application.main()
   *
   */
  main () {
  }

  /**
   * @function back
   * @summary go application back
   * @example
   * application.back()
   *
   */
  back () {
  }

  /**
   * @function show
   * @summary show application to screen.<br/>but does not change application layer order
   * @example
   * application.show()
   *
   */
  show () {
  }

  /**
   * @function hide
   * @summary hide application to screen
   * @example
   * application.hide()
   *
   */
  hide () {
  }

  /**
   * @function getDescriptor
   * @summary return widget descriptor object
   * @return {object}   - WidgetDescriptor
   * @example
   * var widgetDescriptor = application.getDescriptor()
   *
   */
  getDescriptor () {
  }

  /**
   * @function destroyApplication
   * @summary destroy application and remove from application tree and deallocate resource. <br/>
   * if exist child application, destroy child application too. <br/>
   * window also removed.
   * @return {object}   - WidgetDescriptor
   * @example
   * var destroyedApp = application.destroyApplication()
   *
   */
  destroyApplication () {
  }



  /**
   * @function postMessage
   * @summary send message to other applications
   * @param {string} message - message to send
   * @param {string} targetOrigin - text string that combination with widget id of receiver application and filter name
   * @param {object} replyTarget - BinderDescriptor to reply message
   * @example
   * var widgetId = application.getDescripor().id
   * var targetOrigin = widgetId + '?filter-name=hello'
   * application.postMessage('message to send', targetOrigin, null)
   *
   */
  postMessage (message, targetOrigin) {
  }

  /**
   * @function registerMessageListener
   * @summary register filter name to receive message from postMessage function
   * @param {string} filterName - filter name for message receive
   * @example
   * var filterName = 'hello'
   * application.registerMessageListener(filterName)
   *
   */
  registerMessageListener(filterName) {
  }

  /**
   * @function unregisterMessageListener
   * @summary unregister filter name
   * @param {string} filterName - filter name for message receive
   * @example
   * var filterName = 'hello'
   * application.unregisterMessageListener(filterName)
   *
   */
  unregisterMessageListener(filterName) {
  }

  /**
   * @function requestNativeScreen
   * @summary to a open system screen
   * @param {integer} type - 0: screen hide<br/>1: video player screen<br/>2: picture viewer screen<br/>3: eco drive screen
   * @example
   * var type = 1  // video player screen
   * application.requestNativeScreen(type)
   *
   */
  requestNativeScreen (type) {
  }

  /**
   * @function getAmbientColor
   * @summary to get ambient colors
   * @return {string} ambientColor - ambient color
   * @example
   * var nowColor = application.getAmbientColor()
   *
   */
  getAmbientColor () {
  }

  /**
   * @function getLanguage
   * @summary to get current language of widgets
   * @return {string} lang - widgets language
   * @example
   * var nowLang = application.getLanguage()
   *
   */
  getLanguage () {
  }

  /**
   * @function getStatusBarTitle
   * @summary to get a status bar title
   * @return {string} title - status bar title
   * @example
   * var nowTitle = application.getStatusBarTitle()
   *
   */
  getStatusBarTitle () {
  }

  /**
   * @function setStatusBarTitle
   * @summary to set a text title to the status bar
   * @param {string} title - title to set
   * @example
   * var newTitle = 'Hello World!'
   * application.setStatusBarTitle(newTitle)
   *
   */
  setStatusBarTitle (title) {
  }

  /**
   * @function requestPopup
   * @summary to open popup to native
   * @param {integer} type - popup type.<br/>0: no popup<br/>1: top toast popup<br/>2: center toast popup<br/>3: bottom toast popup<br/>4: center popup
   * @param {string} title - popup title
   * @param {string} content  - popup content
   * @param {array} button - label of popup buttons
   * @example
   * var type = 4  // center popup
   * var title = 'popup title'
   * var content = 'popup content'
   * var buttons = ['OK', 'Cancel']
   * application.requestPopup(type, title, content, buttons)
   *
   */
  requestPopup (type, title, content, buttons) {
  }

  /**
   * @function isPopupActive
   * @summary to check popup is open
   * @return {boolean} open - if popup open, return true.
   * @example
   * var isPopupShown = application.isPopupActive()
   *
   */
  isPopupActive () {
  }

  /**
   * @function getCommonLibraryPath
   * @summary to get common javascript library path
   * @return {string} path - common library path
   * @example
   * var commonLibPath = application.getCommonLibraryPath()
   *
   */
  getCommonLibraryPath () {
  }



  // properties ////////////////////////////
  constructor(){
    /**
     * @member visiable
     * @type boolean
     * @summary application's visible/hidden status
     * @example
     * var isVisible = application.visible
     *
     */
    this.visible;

    /**
     * @member active
     * @type boolean
     * @summary application active/deactive status
     * @example
     * var isActive = application.active
     *
     */
    this.active;


    /**
     * @member isPrimiaryReceiver
     * @type boolean
     * @summary true if application received event earlier than other applications.
     * @example
     * var isPR = application.isPrimiaryReceiver
     *
     */
    this.isPrimiaryReceiver;

    /**
     * @member type
     * @type integer
     * @summary type of application. <br/>
     * gadget or fullscreen app. <br/>
     * 1: fullscreen app mode<br/>2: gedget mode
     * @example
     * var appType = application.type
     *
     */
    this.type;

  }

}

