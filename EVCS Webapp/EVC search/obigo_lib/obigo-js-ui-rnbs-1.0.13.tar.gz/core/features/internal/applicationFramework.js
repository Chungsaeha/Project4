/**
 * @module applicationFramework
 * @desc applicationFramework object has information of current Obigo AF/Apps framework.
 * <br/> it is a internal object that is injected by Obigo browser in window object
 * @example 
 * var appFrm = window.applicationFramework
 */

class applicationFramework {

  /**
   * @function getVersion
   * @summary return application framework(Obigo AF) version
   * @return {string}  - framework version
   * @example
   * var appFrm = window.applicationFramework
   * appFrm.getVersion()
   * 
   */
  getVersion () {
  }

  /**
   * @function getResourceVersion
   * @summary return application framework resource(webapp packages) version
   * @return {string}  - framework resource version
   * @example
   * var appFrm = window.applicationFramework
   * appFrm.getResourceVersion()
   */
  getResourceVersion () {
  }

  /**
   * @function getWebLauncherVersion
   * @summary return web launcher version
   * @return {string}  - web launcher version
   * @example
   * var appFrm = window.applicationFramework
   * appFrm.getwebLauncherVersion()
   */
  getWebLauncherVersion () {
  }

  constructor () {
    /**
     * @member applicationManager
     * @type ApplicationManager
     * @summary ApplicationManager object
     * @example
     * var appFrm = window.applicationFramework
     * var appMgr = appFrm.applicationManager
     *
     */
    this.applicationManager;
  }
}

