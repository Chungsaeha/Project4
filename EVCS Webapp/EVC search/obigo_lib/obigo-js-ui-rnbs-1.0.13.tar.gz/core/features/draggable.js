const isTouchSupported = 'ontouchstart' in window
const startEvent = isTouchSupported ? 'touchstart' : 'mousedown'
const moveEvent = isTouchSupported ? 'touchmove' : 'mousemove'
const endEvent = isTouchSupported ? 'touchend' : 'mouseup'
let isDragging = false

export default function (element, options) {
  const moveStart = function (event) {
    if (options.drag) {
      options.drag(event)
    }
  }
  const moveEnd = function (event) {
    document.removeEventListener(moveEvent, moveStart)
    document.removeEventListener(endEvent, moveEnd)

    document.onselectstart = null
    document.ondragstart = null

    isDragging = false

    if (options.end) {
      options.end(event)
    }
  }
  element.addEventListener(startEvent, function (event) {
    if (isDragging) return
    event.preventDefault()
    document.onselectstart = function () { return false }
    document.ondragstart = function () { return false }

    document.addEventListener(moveEvent, moveStart)
    document.addEventListener(endEvent, moveEnd)

    isDragging = true

    if (options.start) {
      options.start(event)
    }
  })
}
